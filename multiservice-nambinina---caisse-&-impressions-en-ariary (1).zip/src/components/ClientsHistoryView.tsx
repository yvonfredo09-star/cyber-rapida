import React, { useState, useMemo } from 'react';
import {
  Users,
  Search,
  Phone,
  Clock,
  Calendar,
  CreditCard,
  CheckCircle,
  FileText,
  DollarSign,
  ChevronRight,
  ArrowUpRight,
  Share2,
  Banknote,
} from 'lucide-react';
import { Transaction, ClientSummary, PaymentMethod } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface ClientsHistoryViewProps {
  transactions: Transaction[];
  onSettleDebt: (clientName: string, paymentMethod: PaymentMethod) => void;
  currency: string;
}

export const ClientsHistoryView: React.FC<ClientsHistoryViewProps> = ({
  transactions,
  onSettleDebt,
  currency,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedClientName, setSelectedClientName] = useState<string | null>(null);
  const [showSettleModal, setShowSettleModal] = useState(false);

  // Compute aggregate Client summaries
  const clientsMap = useMemo(() => {
    const map = new Map<string, ClientSummary>();

    transactions.forEach((tx) => {
      const name = tx.clientName.trim() || 'Client Comptoir';
      const existing = map.get(name);

      const isDebt = tx.paymentStatus === 'credit';
      const debtAmount = isDebt ? tx.totalAmount : 0;

      if (!existing) {
        map.set(name, {
          name,
          phone: tx.clientPhone,
          totalSpent: tx.totalAmount,
          totalTransactions: 1,
          debtBalance: debtAmount,
          lastVisit: `${tx.dateString} à ${tx.timeString}`,
          lastVisitTimestamp: tx.timestamp,
        });
      } else {
        existing.totalSpent += tx.totalAmount;
        existing.totalTransactions += 1;
        existing.debtBalance += debtAmount;
        if (!existing.phone && tx.clientPhone) {
          existing.phone = tx.clientPhone;
        }
        if (tx.timestamp > existing.lastVisitTimestamp) {
          existing.lastVisit = `${tx.dateString} à ${tx.timeString}`;
          existing.lastVisitTimestamp = tx.timestamp;
        }
      }
    });

    return Array.from(map.values()).sort(
      (a, b) => b.lastVisitTimestamp - a.lastVisitTimestamp
    );
  }, [transactions]);

  const filteredClients = useMemo(() => {
    return clientsMap.filter((c) => {
      const q = searchTerm.toLowerCase();
      const matchName = c.name.toLowerCase().includes(q);
      const matchPhone = c.phone ? c.phone.toLowerCase().includes(q) : false;
      return matchName || matchPhone;
    });
  }, [clientsMap, searchTerm]);

  // Selected client's specific transaction history
  const activeClient = useMemo(() => {
    if (!selectedClientName) return clientsMap[0] || null;
    return clientsMap.find((c) => c.name === selectedClientName) || null;
  }, [selectedClientName, clientsMap]);

  const clientTransactions = useMemo(() => {
    if (!activeClient) return [];
    return transactions
      .filter((t) => t.clientName.trim() === activeClient.name)
      .sort((a, b) => b.timestamp - a.timestamp);
  }, [activeClient, transactions]);

  const handleConfirmSettle = () => {
    if (!activeClient) return;
    onSettleDebt(activeClient.name, 'especes');
    setShowSettleModal(false);
  };

  return (
    <div className="space-y-5">
      {/* Search and Summary bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-sm transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Répertoire & Historique par Client
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              {clientsMap.length} client(s) répertorié(s) au kiosque
            </p>
          </div>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par nom ou numéro..."
            className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
          />
        </div>
      </div>

      {/* Main Split Layout: Clients List (Left) + Detailed History (Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left Column: Client List (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-2">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 shadow-sm transition-colors">
            {filteredClients.length === 0 ? (
              <div className="p-8 text-center text-slate-500 text-xs">
                Aucun client trouvé pour cette recherche.
              </div>
            ) : (
              filteredClients.map((client) => {
                const isSelected = activeClient?.name === client.name;
                return (
                  <div
                    key={client.name}
                    onClick={() => setSelectedClientName(client.name)}
                    className={`p-3.5 flex items-center justify-between cursor-pointer transition-colors ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-500/10 border-l-4 border-emerald-500'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                    }`}
                  >
                    <div className="space-y-1 min-w-0 pr-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900 dark:text-slate-100 truncate">
                          {client.name}
                        </span>
                        {client.debtBalance > 0 && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-400">
                            Dette
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                        {client.phone && (
                          <span className="font-mono text-slate-700 dark:text-slate-300">{client.phone}</span>
                        )}
                        <span>•</span>
                        <span>{client.totalTransactions} passage(s)</span>
                      </div>

                      <p className="text-[10px] text-slate-400 dark:text-slate-500">
                        Dernière visite : {client.lastVisit}
                      </p>
                    </div>

                    <div className="text-right shrink-0">
                      <p className="font-mono font-bold text-xs text-slate-900 dark:text-white tabular-nums">
                        {formatCurrency(client.totalSpent, currency)}
                      </p>
                      {client.debtBalance > 0 ? (
                        <p className="text-[11px] font-mono text-amber-600 dark:text-amber-400 font-bold">
                          Dû : {formatCurrency(client.debtBalance, currency)}
                        </p>
                      ) : (
                        <p className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold">À jour</p>
                      )}
                      <ChevronRight className="w-4 h-4 text-slate-400 inline ml-1 mt-1" />
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Column: Detailed Transaction Ledger for Active Client (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-4">
          {activeClient ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm transition-colors">
              {/* Client Profile Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-black text-slate-900 dark:text-white">{activeClient.name}</h3>
                    {activeClient.debtBalance > 0 ? (
                      <span className="px-2 py-0.5 rounded text-xs font-bold bg-amber-100 dark:bg-amber-500/20 text-amber-700 dark:text-amber-400 border border-amber-300 dark:border-amber-500/30">
                        Dette en cours
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-xs font-bold bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-emerald-500/30">
                        Solde réglé
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                    {activeClient.phone && (
                      <span className="font-mono text-slate-700 dark:text-slate-300">
                        Tél : {activeClient.phone}
                      </span>
                    )}
                    <span>• Total dépensé : <strong className="text-slate-900 dark:text-white font-mono">{formatCurrency(activeClient.totalSpent, currency)}</strong></span>
                  </div>
                </div>

                {/* Settle Debt Button if any */}
                {activeClient.debtBalance > 0 && (
                  <button
                    onClick={() => setShowSettleModal(true)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black uppercase transition shadow-md shadow-amber-500/20 whitespace-nowrap"
                  >
                    <CheckCircle className="w-4 h-4 stroke-[2.5]" />
                    <span>Régler Dette en Ariary ({formatCurrency(activeClient.debtBalance, currency)})</span>
                  </button>
                )}
              </div>

              {/* Transactions History List */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
                  Détail de toutes les opérations ({clientTransactions.length})
                </h4>

                <div className="space-y-3">
                  {clientTransactions.map((tx) => (
                    <div
                      key={tx.id}
                      className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/90 space-y-2.5 text-xs transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-slate-500 dark:text-slate-400">
                            {tx.timeString}
                          </span>
                          <span className="text-slate-300 dark:text-slate-600">•</span>
                          <span className="text-slate-700 dark:text-slate-300">{tx.dateString}</span>
                          <span className="text-slate-300 dark:text-slate-600">•</span>
                          <span className="text-[11px] text-slate-500 dark:text-slate-400">
                            Guichet: {tx.cashierName || 'Gérant'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-transparent">
                            Espèces (Ariary)
                          </span>

                          <span className="font-mono font-black text-sm text-slate-900 dark:text-white tabular-nums">
                            {formatCurrency(tx.totalAmount, currency)}
                          </span>
                        </div>
                      </div>

                      {/* Line items detail */}
                      <div className="pt-2 border-t border-slate-200 dark:border-slate-900 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                        {tx.items.map((item, idx) => (
                          <div
                            key={idx}
                            className="flex items-center justify-between p-1.5 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800/80 text-[11px]"
                          >
                            <span className="text-slate-800 dark:text-slate-200 truncate pr-2">
                              {item.quantity}x {item.taskName}
                            </span>
                            <span className="font-mono text-emerald-600 dark:text-emerald-400 font-bold shrink-0">
                              {formatCurrency(item.total, currency)}
                            </span>
                          </div>
                        ))}
                      </div>

                      {tx.notes && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 italic">
                          Note : {tx.notes}
                        </p>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-slate-500 text-xs shadow-sm">
              Sélectionnez un client à gauche pour consulter son historique complet.
            </div>
          )}
        </div>
      </div>

      {/* Settle Debt Modal */}
      {showSettleModal && activeClient && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Régulariser la Dette de {activeClient.name}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300">
              Montant total de la dette :{' '}
              <strong className="text-amber-600 dark:text-amber-400 font-mono text-sm">
                {formatCurrency(activeClient.debtBalance, currency)}
              </strong>
            </p>

            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 rounded-xl text-xs space-y-1">
              <span className="font-bold text-emerald-800 dark:text-emerald-300 flex items-center gap-1.5">
                <Banknote className="w-4 h-4" />
                Mode de règlement : Seulement en Ariary
              </span>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Encaissement direct en espèces Ariary au tiroir caisse.
              </p>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => setShowSettleModal(false)}
                className="w-1/2 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
              >
                Annuler
              </button>
              <button
                onClick={handleConfirmSettle}
                className="w-1/2 py-2 rounded-xl bg-emerald-500 text-slate-950 text-xs font-black uppercase hover:bg-emerald-400 transition shadow-md shadow-emerald-500/20"
              >
                Confirmer l'encaissement
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
