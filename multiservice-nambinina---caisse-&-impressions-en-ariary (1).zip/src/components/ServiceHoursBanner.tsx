import React from 'react';
import { Clock, Calendar, CheckCircle, AlertTriangle, XCircle, Settings } from 'lucide-react';
import { BusinessSettings } from '../types';
import { ServiceHoursStatus } from '../utils/serviceHours';

interface ServiceHoursBannerProps {
  settings: BusinessSettings;
  status: ServiceHoursStatus;
  currentTimeString: string;
  onEditHours: () => void;
}

export const ServiceHoursBanner: React.FC<ServiceHoursBannerProps> = ({
  settings,
  status,
  currentTimeString,
  onEditHours,
}) => {
  const today = new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 shadow-sm transition-colors">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: Hours & Status */}
        <div className="flex items-start sm:items-center gap-3.5">
          <div
            className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${
              status.isOpen
                ? status.isClosingSoon
                  ? 'bg-amber-500/10 text-amber-500 dark:text-amber-400 border border-amber-500/30'
                  : 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                : 'bg-rose-500/10 text-rose-500 dark:text-rose-400 border border-rose-500/30'
            }`}
          >
            {status.isOpen ? (
              status.isClosingSoon ? (
                <AlertTriangle className="w-5 h-5" />
              ) : (
                <CheckCircle className="w-5 h-5" />
              )
            ) : (
              <XCircle className="w-5 h-5" />
            )}
          </div>

          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                  status.isOpen
                    ? status.isClosingSoon
                      ? 'bg-amber-500/20 text-amber-700 dark:text-amber-300'
                      : 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300'
                    : 'bg-rose-500/20 text-rose-700 dark:text-rose-300'
                }`}
              >
                {status.statusLabel}
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">{status.timeRemainingText}</span>
            </div>

            <div className="flex flex-wrap items-center gap-3 mt-1.5 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>
                  Heures de service :{' '}
                  <strong className="text-slate-900 dark:text-white font-semibold">
                    {settings.openingTime} à {settings.closingTime}
                  </strong>
                </span>
              </div>
              <span className="text-slate-300 dark:text-slate-600 hidden md:inline">•</span>
              <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400">
                <Calendar className="w-3.5 h-3.5 text-sky-500 dark:text-sky-400" />
                <span className="capitalize">{today}</span>
                <span className="text-emerald-600 dark:text-emerald-400 font-mono font-semibold ml-1">
                  [{currentTimeString}]
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Right: Quick actions */}
        <div className="flex items-center gap-2 self-end sm:self-center">
          <div className="text-[11px] text-slate-500 dark:text-slate-400 hidden xl:block text-right">
            <span>Jours ouvrés : </span>
            <span className="text-slate-700 dark:text-slate-300 font-medium">
              {settings.daysOpen.join(', ')}
            </span>
          </div>
          <button
            onClick={onEditHours}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-medium border border-slate-200 dark:border-transparent transition-colors"
            title="Modifier les horaires du kiosque"
          >
            <Settings className="w-3.5 h-3.5" />
            <span>Changer Horaires</span>
          </button>
        </div>
      </div>
    </div>
  );
};
