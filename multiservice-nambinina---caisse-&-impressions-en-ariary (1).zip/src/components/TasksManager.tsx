import React, { useState } from 'react';
import {
  Plus,
  Edit2,
  Trash2,
  Search,
  Printer,
  Copy,
  Files,
  Scan,
  ShieldCheck,
  FileText,
  Folder,
  Mail,
  BookOpen,
  RotateCcw,
  X,
} from 'lucide-react';
import { TaskType, ServiceCategory } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface TasksManagerProps {
  tasks: TaskType[];
  onAddTask: (task: Omit<TaskType, 'id'>) => void;
  onUpdateTask: (task: TaskType) => void;
  onDeleteTask: (id: string) => void;
  onResetDefaults: () => void;
  currency: string;
}

export const TasksManager: React.FC<TasksManagerProps> = ({
  tasks,
  onAddTask,
  onUpdateTask,
  onDeleteTask,
  onResetDefaults,
  currency,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskType | null>(null);

  // Form State
  const [formName, setFormName] = useState('');
  const [formCategory, setFormCategory] = useState<ServiceCategory>('impressions_copies');
  const [formPrice, setFormPrice] = useState('300');
  const [formUnitLabel, setFormUnitLabel] = useState('page');
  const [formIcon, setFormIcon] = useState('Printer');
  const [formActive, setFormActive] = useState(true);

  const openCreateModal = () => {
    setEditingTask(null);
    setFormName('');
    setFormCategory('impressions_copies');
    setFormPrice('300');
    setFormUnitLabel('page');
    setFormIcon('Printer');
    setFormActive(true);
    setIsModalOpen(true);
  };

  const openEditModal = (task: TaskType) => {
    setEditingTask(task);
    setFormName(task.name);
    setFormCategory(task.category);
    setFormPrice(task.unitPrice.toString());
    setFormUnitLabel(task.unitLabel);
    setFormIcon(task.icon);
    setFormActive(task.active);
    setIsModalOpen(true);
  };

  const handleSaveForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    const priceNum = parseFloat(formPrice) || 0;

    const taskColor =
      formCategory === 'finition_reliure'
        ? 'amber'
        : formCategory === 'fournitures'
        ? 'sky'
        : formCategory === 'scan_informatique'
        ? 'purple'
        : 'emerald';

    if (editingTask) {
      onUpdateTask({
        ...editingTask,
        name: formName.trim(),
        category: formCategory,
        unitPrice: priceNum,
        unitCost: editingTask.unitCost || 0,
        unitLabel: formUnitLabel.trim() || 'unité',
        icon: formIcon,
        color: taskColor,
        active: formActive,
      });
    } else {
      onAddTask({
        name: formName.trim(),
        category: formCategory,
        unitPrice: priceNum,
        unitCost: 0,
        unitLabel: formUnitLabel.trim() || 'unité',
        icon: formIcon,
        color: taskColor,
        active: formActive,
      });
    }

    setIsModalOpen(false);
  };

  const filteredTasks = tasks.filter((t) => {
    const matchesSearch = t.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = categoryFilter === 'all' || t.category === categoryFilter;
    return matchesSearch && matchesCat;
  });

  const iconOptions = [
    { label: 'Imprimante', val: 'Printer' },
    { label: 'Photocopie', val: 'Copy' },
    { label: 'Document Recto/Verso', val: 'Files' },
    { label: 'Numérisation / Scan', val: 'Scan' },
    { label: 'Plastification', val: 'ShieldCheck' },
    { label: 'Saisie / Rédaction', val: 'FileText' },
    { label: 'Reliure', val: 'BookOpen' },
    { label: 'Fourniture / Chemise', val: 'Folder' },
    { label: 'Enveloppe', val: 'Mail' },
  ];

  const renderIcon = (iconName: string) => {
    switch (iconName) {
      case 'Printer': return <Printer className="w-4 h-4" />;
      case 'Copy': return <Copy className="w-4 h-4" />;
      case 'Files': return <Files className="w-4 h-4" />;
      case 'Scan': return <Scan className="w-4 h-4" />;
      case 'ShieldCheck': return <ShieldCheck className="w-4 h-4" />;
      case 'FileText': return <FileText className="w-4 h-4" />;
      case 'BookOpen': return <BookOpen className="w-4 h-4" />;
      case 'Folder': return <Folder className="w-4 h-4" />;
      case 'Mail': return <Mail className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  const categoryLabels: Record<ServiceCategory, string> = {
    impressions_copies: 'Impressions & Copies',
    scan_informatique: 'Scan & Informatique',
    finition_reliure: 'Plastification & Reliure',
    fournitures: 'Fournitures',
    autre: 'Autre prestation',
  };

  return (
    <div className="space-y-5">
      {/* Top action bar: Search, filters, Add task button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-sm transition-colors">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
          {/* Search */}
          <div className="relative flex-1 max-w-sm">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Rechercher une tâche (ex: Impression, Scan...)"
              className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Category Filter */}
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            {[
              { id: 'all', label: 'Toutes' },
              { id: 'impressions_copies', label: 'Impressions & Copies' },
              { id: 'scan_informatique', label: 'Scan & Saisie' },
              { id: 'finition_reliure', label: 'Reliure & Plastif.' },
              { id: 'fournitures', label: 'Fournitures' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setCategoryFilter(cat.id)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors whitespace-nowrap ${
                  categoryFilter === cat.id
                    ? 'bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border border-emerald-500/40'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white bg-slate-100 dark:bg-slate-950/60'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onResetDefaults}
            className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white transition"
            title="Réinitialiser les tâches par défaut (Ariary)"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <button
            onClick={openCreateModal}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs uppercase shadow-md shadow-emerald-500/20 transition"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>Nouveau Service (CRUD)</span>
          </button>
        </div>
      </div>

      {/* Task List Table / Cards */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm transition-colors">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 uppercase tracking-wider font-semibold text-[11px]">
                <th className="py-3 px-4">Tâche / Prestation</th>
                <th className="py-3 px-3">Catégorie</th>
                <th className="py-3 px-3">Prix Client ({currency})</th>
                <th className="py-3 px-3">Statut</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
              {filteredTasks.length === 0 ? (
                <tr>
                  <td colSpan={5} className="py-8 text-center text-slate-500">
                    Aucune tâche trouvée. Créez-en une nouvelle avec le bouton ci-dessus.
                  </td>
                </tr>
              ) : (
                filteredTasks.map((task) => {
                  return (
                    <tr
                      key={task.id}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-3">
                          <div
                            className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                              task.category === 'finition_reliure'
                                ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400'
                                : task.category === 'fournitures'
                                ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400'
                                : task.category === 'scan_informatique'
                                ? 'bg-purple-500/15 text-purple-600 dark:text-purple-400'
                                : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400'
                            }`}
                          >
                            {renderIcon(task.icon)}
                          </div>
                          <div>
                            <p className="font-bold text-slate-900 dark:text-slate-100">{task.name}</p>
                            <p className="text-[11px] text-slate-500 dark:text-slate-400">
                              Unité : {task.unitLabel}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 px-3">
                        <span className="text-slate-700 dark:text-slate-300 font-medium">
                          {categoryLabels[task.category] || task.category}
                        </span>
                      </td>

                      <td className="py-3 px-3 font-mono font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                        {formatCurrency(task.unitPrice, currency)}
                      </td>

                      <td className="py-3 px-3">
                        <button
                          onClick={() =>
                            onUpdateTask({ ...task, active: !task.active })
                          }
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase transition ${
                            task.active
                              ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-200'
                              : 'bg-rose-100 dark:bg-rose-500/20 text-rose-700 dark:text-rose-400 hover:bg-rose-200'
                          }`}
                        >
                          {task.active ? 'Actif' : 'Désactivé'}
                        </button>
                      </td>

                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => openEditModal(task)}
                            className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition"
                            title="Modifier cette tâche"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(`Supprimer la tâche "${task.name}" ?`)) {
                                onDeleteTask(task.id);
                              }
                            }}
                            className="p-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 dark:bg-rose-950/40 dark:hover:bg-rose-900/60 text-rose-600 dark:text-rose-400 transition"
                            title="Supprimer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CRUD MODAL: Add / Edit Task */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                {editingTask ? 'Modifier le Type de Tâche' : 'Nouveau Type de Service (CRUD)'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveForm} className="space-y-4">
              <div className="space-y-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Nom du service (ex: Impression N&B, Photocopie, Scan, Saisie CV, Reliure...) :
                  </label>
                  <input
                    type="text"
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    placeholder="Nom du service..."
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Catégorie :
                    </label>
                    <select
                      value={formCategory}
                      onChange={(e) => setFormCategory(e.target.value as ServiceCategory)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    >
                      <option value="impressions_copies">Impressions & Copies</option>
                      <option value="scan_informatique">Scan & Informatique / Saisie</option>
                      <option value="finition_reliure">Plastification & Reliure</option>
                      <option value="fournitures">Fournitures & Chemises</option>
                      <option value="autre">Autre prestation</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Unité :
                    </label>
                    <input
                      type="text"
                      value={formUnitLabel}
                      onChange={(e) => setFormUnitLabel(e.target.value)}
                      placeholder="page, feuille, pièce, doc, heure..."
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Prix de vente client ({currency}) :
                  </label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={formPrice}
                    onChange={(e) => setFormPrice(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono text-emerald-600 dark:text-emerald-400 font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                      Icône :
                    </label>
                    <select
                      value={formIcon}
                      onChange={(e) => setFormIcon(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                    >
                      {iconOptions.map((opt) => (
                        <option key={opt.val} value={opt.val}>
                          {opt.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex flex-col justify-end space-y-2">
                    <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700 dark:text-slate-300">
                      <input
                        type="checkbox"
                        checked={formActive}
                        onChange={(e) => setFormActive(e.target.checked)}
                        className="rounded border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 text-emerald-500 focus:ring-0"
                      />
                      <span>Service actif au guichet</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black uppercase transition shadow-md shadow-emerald-500/20"
                >
                  {editingTask ? 'Mettre à jour' : 'Créer la Tâche'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
