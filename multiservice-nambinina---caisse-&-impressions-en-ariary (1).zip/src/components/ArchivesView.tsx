import React, { useState, useEffect } from 'react';
import {
  Archive,
  Calendar,
  CheckCircle,
  FileText,
  Download,
  Printer,
  User,
  DollarSign,
  Edit2,
  Trash2,
  X,
  Clock,
  Banknote,
  AlertCircle,
  Save,
} from 'lucide-react';
import { DailyClosing } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface ArchivesViewProps {
  closings: DailyClosing[];
  currency: string;
  onUpdateClosing?: (closing: DailyClosing) => void;
  onDeleteClosing?: (id: string) => void;
}

export const ArchivesView: React.FC<ArchivesViewProps> = ({
  closings,
  currency,
  onUpdateClosing,
  onDeleteClosing,
}) => {
  const [selectedClosingId, setSelectedClosingId] = useState<string | null>(
    closings[0]?.id || null
  );
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Keep selectedClosing synced with latest closings
  const selectedClosing = closings.find((c) => c.id === selectedClosingId) || closings[0] || null;

  useEffect(() => {
    if (!selectedClosing && closings.length > 0) {
      setSelectedClosingId(closings[0].id);
    }
  }, [closings, selectedClosing]);

  // Edit form state
  const [formDate, setFormDate] = useState('');
  const [formTime, setFormTime] = useState('');
  const [formCashier, setFormCashier] = useState('');
  const [formOpeningCash, setFormOpeningCash] = useState('0');
  const [formBureautique, setFormBureautique] = useState('0');
  const [formFournitures, setFormFournitures] = useState('0');
  const [formExpenses, setFormExpenses] = useState('0');
  const [formCountedCash, setFormCountedCash] = useState('0');
  const [formNotes, setFormNotes] = useState('');

  const openEditModal = (closing: DailyClosing) => {
    setSelectedClosingId(closing.id);
    setFormDate(closing.dateString);
    setFormTime(closing.closedTimeString);
    setFormCashier(closing.cashierName);
    setFormOpeningCash(closing.openingCash.toString());
    setFormBureautique(closing.totalBureautiqueRevenue.toString());
    setFormFournitures((closing.totalFournituresRevenue || 0).toString());
    setFormExpenses(closing.totalExpenses.toString());
    setFormCountedCash(closing.countedCash.toString());
    setFormNotes(closing.notes || '');
    setIsEditModalOpen(true);
  };

  // Dynamic preview calculations for the edit form
  const parsedOpening = parseFloat(formOpeningCash) || 0;
  const parsedBureautique = parseFloat(formBureautique) || 0;
  const parsedFournitures = parseFloat(formFournitures) || 0;
  const parsedExpenses = parseFloat(formExpenses) || 0;
  const parsedCounted = parseFloat(formCountedCash) || 0;

  const previewTotalRevenue = parsedBureautique + parsedFournitures;
  const previewTheoreticalCash = parsedOpening + previewTotalRevenue - parsedExpenses;
  const previewDifference = parsedCounted - previewTheoreticalCash;
  const previewNetProfit = previewTotalRevenue - parsedExpenses;

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedClosing) return;

    const updated: DailyClosing = {
      ...selectedClosing,
      dateString: formDate.trim() || selectedClosing.dateString,
      closedTimeString: formTime.trim() || selectedClosing.closedTimeString,
      cashierName: formCashier.trim() || selectedClosing.cashierName,
      openingCash: parsedOpening,
      totalBureautiqueRevenue: parsedBureautique,
      totalFournituresRevenue: parsedFournitures,
      totalExpenses: parsedExpenses,
      totalCashIn: previewTotalRevenue,
      totalCashOut: parsedExpenses,
      theoreticalCash: previewTheoreticalCash,
      countedCash: parsedCounted,
      difference: previewDifference,
      netProfitEstimate: previewNetProfit,
      notes: formNotes.trim(),
    };

    onUpdateClosing?.(updated);
    setIsEditModalOpen(false);
  };

  const handleDelete = (id: string, dateString: string) => {
    if (window.confirm(`Supprimer définitivement la clôture archivée du ${dateString} ?`)) {
      onDeleteClosing?.(id);
      if (selectedClosingId === id) {
        const remaining = closings.filter((c) => c.id !== id);
        setSelectedClosingId(remaining[0]?.id || null);
      }
      setIsEditModalOpen(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Top Header Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-sm transition-colors">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
            <Archive className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Archives des Clôtures Journalières
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Historique des bilans de caisse enregistrés chaque soir (Multiservice Nambinina)
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-500 dark:text-slate-400">
            {closings.length} clôture(s) archivée(s)
          </span>
        </div>
      </div>

      {closings.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center text-slate-500 text-xs space-y-2 shadow-sm">
          <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
            Aucune clôture archivée pour le moment.
          </p>
          <p>
            Chaque soir, cliquez sur le bouton vert <strong>"Capture du Soir"</strong> en haut pour
            générer et archiver la clôture officielle de la journée.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left: List of archived dates */}
          <div className="lg:col-span-4 space-y-2">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl divide-y divide-slate-100 dark:divide-slate-800 overflow-hidden shadow-sm transition-colors">
              {closings.map((c) => {
                const isSelected = selectedClosing?.id === c.id;
                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedClosingId(c.id)}
                    className={`p-3.5 cursor-pointer transition flex items-center justify-between group ${
                      isSelected
                        ? 'bg-emerald-50 dark:bg-emerald-500/15 border-l-4 border-emerald-500'
                        : 'hover:bg-slate-50 dark:hover:bg-slate-800/40'
                    }`}
                  >
                    <div>
                      <p className="font-bold text-xs text-slate-900 dark:text-slate-200 flex items-center gap-2">
                        <span>{c.dateString}</span>
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        Clôturé à {c.closedTimeString} par {c.cashierName}
                      </p>
                    </div>

                    <div className="text-right flex items-center gap-2">
                      <div>
                        <p className="font-mono font-bold text-xs text-emerald-600 dark:text-emerald-400 tabular-nums">
                          {formatCurrency(c.netProfitEstimate, currency)}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {c.totalTransactionsCount} ventes
                        </p>
                      </div>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          openEditModal(c);
                        }}
                        className="p-1 rounded-lg text-slate-400 hover:text-emerald-600 dark:hover:text-emerald-400 hover:bg-slate-200 dark:hover:bg-slate-700/60 opacity-80 group-hover:opacity-100 transition"
                        title="Éditer ce bilan archivé"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Selected closing summary */}
          <div className="lg:col-span-8">
            {selectedClosing && (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 text-xs shadow-sm transition-colors">
                {/* Header with Edit Button */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                      Bilan du {selectedClosing.dateString}
                    </h3>
                    <p className="text-slate-500 dark:text-slate-400 text-[11px]">
                      Clôturé à {selectedClosing.closedTimeString} • Responsable : {selectedClosing.cashierName}
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                        selectedClosing.difference === 0
                          ? 'bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400'
                          : 'bg-rose-100 dark:bg-rose-500/20 text-rose-700 dark:text-rose-400'
                      }`}
                    >
                      {selectedClosing.difference === 0
                        ? 'Caisse Équilibrée'
                        : `Écart : ${selectedClosing.difference > 0 ? `+${selectedClosing.difference}` : selectedClosing.difference} ${currency}`}
                    </span>

                    {/* Edit button */}
                    <button
                      onClick={() => openEditModal(selectedClosing)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 text-xs font-bold transition"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                      <span>Éditer le bilan</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <p className="text-slate-500 text-[10px]">Fond d'ouverture</p>
                    <p className="text-xs font-bold font-mono text-slate-900 dark:text-white">
                      {formatCurrency(selectedClosing.openingCash, currency)}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <p className="text-slate-500 text-[10px]">Recettes Bureautique</p>
                    <p className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400">
                      {formatCurrency(selectedClosing.totalBureautiqueRevenue, currency)}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <p className="text-slate-500 text-[10px]">Fournitures & Ventes</p>
                    <p className="text-xs font-bold font-mono text-cyan-600 dark:text-cyan-400">
                      {formatCurrency(selectedClosing.totalFournituresRevenue || 0, currency)}
                    </p>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800">
                    <p className="text-slate-500 text-[10px]">Dépenses Décaissées</p>
                    <p className="text-xs font-bold font-mono text-rose-600 dark:text-rose-400">
                      -{formatCurrency(selectedClosing.totalExpenses, currency)}
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Solde théorique en espèces :</span>
                    <strong className="text-slate-900 dark:text-white font-mono">
                      {formatCurrency(selectedClosing.theoreticalCash, currency)}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 dark:text-slate-400">Solde physique compté :</span>
                    <strong className="text-emerald-600 dark:text-emerald-400 font-mono">
                      {formatCurrency(selectedClosing.countedCash, currency)}
                    </strong>
                  </div>
                  <div className="flex justify-between border-t border-slate-200 dark:border-slate-800/80 pt-2 font-bold text-sm">
                    <span className="text-emerald-600 dark:text-emerald-400">Bénéfice Net de la journée :</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono">
                      {formatCurrency(selectedClosing.netProfitEstimate, currency)}
                    </span>
                  </div>
                </div>

                {selectedClosing.notes && (
                  <p className="text-slate-500 dark:text-slate-400 italic">
                    Remarque : {selectedClosing.notes}
                  </p>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Edit Modal for Archived Closing */}
      {isEditModalOpen && selectedClosing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-xl w-full p-6 space-y-5 shadow-2xl transition-colors">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
                  <Edit2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white">
                    Modifier le Bilan Archivé
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">
                    Corriger les montants, la date, ou les notes de la clôture
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4">
              {/* Date & Time & Cashier */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Date :
                  </label>
                  <input
                    type="date"
                    required
                    value={formDate}
                    onChange={(e) => setFormDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Heure :
                  </label>
                  <input
                    type="text"
                    required
                    value={formTime}
                    onChange={(e) => setFormTime(e.target.value)}
                    placeholder="18:30:00"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Guichetier :
                  </label>
                  <input
                    type="text"
                    required
                    value={formCashier}
                    onChange={(e) => setFormCashier(e.target.value)}
                    placeholder="Caissier"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Financial inputs in Ariary */}
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Fond d'ouverture ({currency}) :
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formOpeningCash}
                    onChange={(e) => setFormOpeningCash(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Recettes Bureautique ({currency}) :
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formBureautique}
                    onChange={(e) => setFormBureautique(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Ventes Fournitures ({currency}) :
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formFournitures}
                    onChange={(e) => setFormFournitures(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-cyan-600 dark:text-cyan-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Dépenses Décaissées ({currency}) :
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={formExpenses}
                    onChange={(e) => setFormExpenses(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-rose-600 dark:text-rose-400 focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>

              {/* Counted physical cash */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Solde physique compté en caisse ({currency}) :
                </label>
                <input
                  type="number"
                  min="0"
                  value={formCountedCash}
                  onChange={(e) => setFormCountedCash(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono font-bold text-emerald-600 dark:text-emerald-400 focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Dynamic calculations summary preview */}
              <div className="p-3 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-500">Total recettes (Bureautique + Fournitures) :</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {formatCurrency(previewTotalRevenue, currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Solde théorique attendu :</span>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {formatCurrency(previewTheoreticalCash, currency)}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Écart de caisse calculé :</span>
                  <span
                    className={`font-mono font-bold ${
                      previewDifference === 0
                        ? 'text-emerald-600 dark:text-emerald-400'
                        : 'text-rose-600 dark:text-rose-400'
                    }`}
                  >
                    {previewDifference === 0
                      ? '0 (Équilibré)'
                      : `${previewDifference > 0 ? `+${previewDifference}` : previewDifference} ${currency}`}
                  </span>
                </div>
                <div className="flex justify-between border-t border-slate-200 dark:border-slate-800 pt-1 font-bold">
                  <span className="text-emerald-600 dark:text-emerald-400">Bénéfice Net :</span>
                  <span className="font-mono text-emerald-600 dark:text-emerald-400">
                    {formatCurrency(previewNetProfit, currency)}
                  </span>
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Remarque / Note du bilan :
                </label>
                <input
                  type="text"
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  placeholder="Remarque éventuelle sur la journée..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              {/* Modal action buttons */}
              <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => handleDelete(selectedClosing.id, selectedClosing.dateString)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 text-xs font-bold transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Supprimer</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsEditModalOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
                  >
                    Annuler
                  </button>
                  <button
                    type="submit"
                    className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black uppercase transition shadow-md shadow-emerald-500/20"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>Sauvegarder</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
