import React, { useState, useMemo } from 'react';
import {
  Printer,
  Copy,
  Files,
  Scan,
  ShieldCheck,
  FileText,
  BookOpen,
  Folder,
  Mail,
  Plus,
  Minus,
  Trash2,
  Check,
  User,
  Phone,
  Banknote,
  Printer as PrintIcon,
  X,
  FileCheck,
  Coins,
} from 'lucide-react';
import { TaskType, Transaction, TransactionItem, PaymentMethod } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface POSRegisterProps {
  tasks: TaskType[];
  onAddTransaction: (tx: Omit<Transaction, 'id' | 'timestamp' | 'dateString' | 'timeString'>) => void;
  currency: string;
  cashierName: string;
  clientsList: { name: string; phone?: string }[];
}

export const POSRegister: React.FC<POSRegisterProps> = ({
  tasks,
  onAddTransaction,
  currency,
  cashierName,
  clientsList,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [basket, setBasket] = useState<TransactionItem[]>([]);
  const [clientName, setClientName] = useState<string>('Client Comptoir');
  const [clientPhone, setClientPhone] = useState<string>('');
  // Mode de règlement : strictement en Ariary
  const [paymentMethod] = useState<PaymentMethod>('especes');
  const [notes, setNotes] = useState<string>('');
  const [cashTendered, setCashTendered] = useState<string>('');
  const [lastCompletedTx, setLastCompletedTx] = useState<Transaction | null>(null);

  // Icon mapping
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Printer': return <Printer className="w-5 h-5" />;
      case 'Copy': return <Copy className="w-5 h-5" />;
      case 'Files': return <Files className="w-5 h-5" />;
      case 'Scan': return <Scan className="w-5 h-5" />;
      case 'ShieldCheck': return <ShieldCheck className="w-5 h-5" />;
      case 'FileText': return <FileText className="w-5 h-5" />;
      case 'BookOpen': return <BookOpen className="w-5 h-5" />;
      case 'Folder': return <Folder className="w-5 h-5" />;
      case 'Mail': return <Mail className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      if (!t.active) return false;
      if (selectedCategory === 'all') return true;
      return t.category === selectedCategory;
    });
  }, [tasks, selectedCategory]);

  const addToBasket = (task: TaskType, qtyToAdd: number = 1) => {
    setBasket((prev) => {
      const existing = prev.find((item) => item.taskTypeId === task.id);
      if (existing) {
        return prev.map((item) =>
          item.taskTypeId === task.id
            ? {
                ...item,
                quantity: item.quantity + qtyToAdd,
                total: (item.quantity + qtyToAdd) * item.unitPrice,
              }
            : item
        );
      } else {
        return [
          ...prev,
          {
            taskTypeId: task.id,
            taskName: task.name,
            category: task.category,
            unitPrice: task.unitPrice,
            quantity: qtyToAdd,
            total: task.unitPrice * qtyToAdd,
          },
        ];
      }
    });
  };

  const updateQuantity = (taskTypeId: string, newQty: number) => {
    if (newQty <= 0) {
      removeFromBasket(taskTypeId);
      return;
    }
    setBasket((prev) =>
      prev.map((item) =>
        item.taskTypeId === taskTypeId
          ? {
              ...item,
              quantity: newQty,
              total: newQty * item.unitPrice,
            }
          : item
      )
    );
  };

  const removeFromBasket = (taskTypeId: string) => {
    setBasket((prev) => prev.filter((item) => item.taskTypeId !== taskTypeId));
  };

  const clearBasket = () => {
    setBasket([]);
    setCashTendered('');
    setNotes('');
  };

  const totalBasketAmount = useMemo(() => {
    return basket.reduce((sum, item) => sum + item.total, 0);
  }, [basket]);

  const tenderedNum = parseFloat(cashTendered) || 0;
  const changeToReturn = tenderedNum > totalBasketAmount ? tenderedNum - totalBasketAmount : 0;

  const handleCheckout = () => {
    if (basket.length === 0) return;

    const newTxData = {
      clientName: clientName.trim() || 'Client Comptoir',
      clientPhone: clientPhone.trim() || undefined,
      items: [...basket],
      subtotal: totalBasketAmount,
      discount: 0,
      totalAmount: totalBasketAmount,
      paymentMethod: 'especes' as const, // Strictement en Ariary
      paymentStatus: 'paye' as const,
      notes: notes.trim() ? `${notes.trim()} (Réglé en Ariary)` : 'Payé en Ariary',
      cashierName,
    };

    onAddTransaction(newTxData);

    const now = new Date();
    setLastCompletedTx({
      id: `TX-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      dateString: now.toISOString().split('T')[0],
      timeString: now.toTimeString().split(' ')[0],
      ...newTxData,
    });

    // Reset ticket
    setBasket([]);
    setCashTendered('');
    setNotes('');
    setClientName('Client Comptoir');
    setClientPhone('');
  };

  // Billets et raccourcis en Ariary (Madagascar)
  const ariaryShortcuts = [500, 1000, 2000, 5000, 10000, 20000, 50000];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      {/* LEFT COLUMN: Catalogue & Quick Touch Tiles */}
      <div className="lg:col-span-7 xl:col-span-8 space-y-4">
        {/* Category Segmented Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar bg-white dark:bg-slate-900/60 p-1.5 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm transition-colors">
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'all'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Tous les Services ({tasks.length})
          </button>
          <button
            onClick={() => setSelectedCategory('impressions_copies')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'impressions_copies'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Impressions & Copies
          </button>
          <button
            onClick={() => setSelectedCategory('scan_informatique')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'scan_informatique'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Scans & Informatique
          </button>
          <button
            onClick={() => setSelectedCategory('finition_reliure')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'finition_reliure'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Plastification & Reliure
          </button>
          <button
            onClick={() => setSelectedCategory('fournitures')}
            className={`px-3.5 py-1.5 text-xs font-medium rounded-lg transition-colors whitespace-nowrap ${
              selectedCategory === 'fournitures'
                ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Fournitures & Chemises
          </button>
        </div>

        {/* Quick Service Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-3">
          {filteredTasks.map((task) => (
            <div
              key={task.id}
              className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500/50 rounded-2xl p-3.5 flex flex-col justify-between transition-all shadow-sm hover:shadow-md active:scale-[0.98]"
            >
              <div
                onClick={() => addToBasket(task, 1)}
                className="cursor-pointer space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      task.category === 'finition_reliure'
                        ? 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30'
                        : task.category === 'fournitures'
                        ? 'bg-sky-500/15 text-sky-600 dark:text-sky-400 border border-sky-500/30'
                        : task.category === 'scan_informatique'
                        ? 'bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30'
                        : 'bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30'
                    }`}
                  >
                    {getIcon(task.icon)}
                  </div>
                  <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 dark:text-slate-500">
                    {task.unitLabel}
                  </span>
                </div>

                <div>
                  <h3 className="text-xs font-bold text-slate-900 dark:text-slate-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-2 leading-snug">
                    {task.name}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                    Par {task.unitLabel}
                  </p>
                </div>

                <div className="pt-1 flex items-baseline justify-between border-t border-slate-100 dark:border-slate-800/80">
                  <span className="text-sm font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                    {formatCurrency(task.unitPrice, currency)}
                  </span>
                  <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-semibold group-hover:underline">
                    + Ajouter
                  </span>
                </div>
              </div>

              {/* Fast Multiplier shortcuts */}
              <div className="mt-2.5 pt-2 border-t border-slate-100 dark:border-slate-800/60 flex items-center gap-1 justify-between">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addToBasket(task, 5);
                  }}
                  className="px-1.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded text-[10px] font-bold transition"
                  title="Ajouter 5 unités"
                >
                  +5
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addToBasket(task, 10);
                  }}
                  className="px-1.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded text-[10px] font-bold transition"
                  title="Ajouter 10 unités"
                >
                  +10
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    addToBasket(task, 20);
                  }}
                  className="px-1.5 py-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 rounded text-[10px] font-bold transition"
                  title="Ajouter 20 unités"
                >
                  +20
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* RIGHT COLUMN: Basket / Ticket en cours */}
      <div className="lg:col-span-5 xl:col-span-4 space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-col justify-between shadow-sm transition-colors">
          {/* Ticket Header & Client Identification */}
          <div className="space-y-3 pb-3 border-b border-slate-200 dark:border-slate-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <FileCheck className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                  Ticket d'Encaissement
                </h2>
              </div>
              {basket.length > 0 && (
                <button
                  onClick={clearBasket}
                  className="text-xs text-rose-500 hover:text-rose-600 dark:text-rose-400 dark:hover:text-rose-300 transition flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Vider</span>
                </button>
              )}
            </div>

            {/* Client Input */}
            <div className="space-y-2">
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Nom du Client ou Comptoir"
                  list="client-suggestions"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
                />
                <datalist id="client-suggestions">
                  {clientsList.map((c, i) => (
                    <option key={i} value={c.name} />
                  ))}
                </datalist>
              </div>

              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  value={clientPhone}
                  onChange={(e) => setClientPhone(e.target.value)}
                  placeholder="Téléphone client (ex: 034 00 000 00)"
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Ticket Items List */}
          <div className="my-3 space-y-2 max-h-64 overflow-y-auto pr-1">
            {basket.length === 0 ? (
              <div className="py-8 text-center text-slate-500 text-xs">
                <p>Aucun article sélectionné.</p>
                <p className="mt-1 text-slate-400">
                  Touchez un service à gauche pour l'ajouter au ticket.
                </p>
              </div>
            ) : (
              basket.map((item) => (
                <div
                  key={item.taskTypeId}
                  className="flex items-center justify-between gap-2 p-2 rounded-xl bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800/80 text-xs"
                >
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-slate-800 dark:text-slate-200 truncate">{item.taskName}</p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 font-mono">
                      {formatCurrency(item.unitPrice, currency)}
                    </p>
                  </div>

                  {/* Quantity selector */}
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => updateQuantity(item.taskTypeId, item.quantity - 1)}
                      className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300"
                    >
                      <Minus className="w-3 h-3" />
                    </button>
                    <span className="w-6 text-center font-bold text-slate-900 dark:text-white font-mono tabular-nums">
                      {item.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(item.taskTypeId, item.quantity + 1)}
                      className="w-6 h-6 rounded bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 flex items-center justify-center text-slate-700 dark:text-slate-300"
                    >
                      <Plus className="w-3 h-3" />
                    </button>

                    <span className="font-bold text-slate-900 dark:text-white font-mono tabular-nums ml-2 w-16 text-right">
                      {formatCurrency(item.total, currency)}
                    </span>

                    <button
                      onClick={() => removeFromBasket(item.taskTypeId)}
                      className="p-1 text-slate-400 hover:text-rose-500 ml-1"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Mode de règlement : Strictement en Ariary */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400">
                  Mode de règlement :
                </label>
                <span className="text-[10px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                  Uniquement en Ariary (Ar)
                </span>
              </div>

              {/* Single Official Payment Method Box */}
              <div className="p-2.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800/80 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0">
                    <Banknote className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-900 dark:text-white">
                      Espèces en Ariary
                    </p>
                    <p className="text-[10px] text-slate-500 dark:text-slate-400">
                      Règlement direct au comptoir (Billets / Pièces)
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-600 dark:text-emerald-400">
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>Actif</span>
                </div>
              </div>
            </div>

            {/* Quick Cash Change Calculator in Ariary */}
            {totalBasketAmount > 0 && (
              <div className="bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-600 dark:text-slate-400 flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5 text-amber-500" />
                    Montant reçu client ({currency}) :
                  </span>
                  <input
                    type="number"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    placeholder="ex: 5000"
                    className="w-24 text-right py-1 px-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded text-xs font-mono text-emerald-600 dark:text-emerald-400 font-bold focus:outline-none"
                  />
                </div>

                {/* Fast Ariary shortcuts */}
                <div className="flex items-center gap-1 justify-end flex-wrap">
                  <button
                    type="button"
                    onClick={() => setCashTendered(totalBasketAmount.toString())}
                    className="px-2 py-0.5 rounded bg-emerald-100 hover:bg-emerald-200 dark:bg-emerald-950/80 text-[10px] font-bold text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-700"
                  >
                    Montant exact
                  </button>
                  {ariaryShortcuts.map((amt) => (
                    <button
                      key={amt}
                      type="button"
                      onClick={() => setCashTendered(amt.toString())}
                      className="px-2 py-0.5 rounded bg-white dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 text-[10px] font-mono text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800"
                    >
                      {new Intl.NumberFormat('fr-FR').format(amt)}
                    </button>
                  ))}
                </div>

                {changeToReturn > 0 && (
                  <div className="flex items-center justify-between pt-1 border-t border-slate-200 dark:border-slate-800 text-xs font-bold">
                    <span className="text-emerald-600 dark:text-emerald-400">Monnaie à rendre :</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-mono text-sm">
                      {formatCurrency(changeToReturn, currency)}
                    </span>
                  </div>
                )}
              </div>
            )}

            {/* Note input */}
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Note sur la transaction (optionnel)..."
              className="w-full px-3 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />

            {/* Total & Checkout button */}
            <div className="space-y-2 pt-2">
              <div className="flex items-baseline justify-between">
                <span className="text-xs uppercase font-bold text-slate-500 dark:text-slate-400">Total à encaisser :</span>
                <span className="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
                  {formatCurrency(totalBasketAmount, currency)}
                </span>
              </div>

              <button
                disabled={basket.length === 0}
                onClick={handleCheckout}
                className="w-full py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 disabled:opacity-40 disabled:cursor-not-allowed text-slate-950 font-black text-sm uppercase tracking-wider shadow-md shadow-emerald-500/20 active:scale-[0.99] transition flex items-center justify-center gap-2"
              >
                <Check className="w-5 h-5 stroke-[3]" />
                <span>Encaisser {formatCurrency(totalBasketAmount, currency)}</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* TICKET RECEIPT MODAL (After checkout) */}
      {lastCompletedTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-sm w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Check className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-white">Encaissement Réussi !</h3>
              </div>
              <button
                onClick={() => setLastCompletedTx(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Printable Receipt Paper */}
            <div
              id="printable-receipt"
              className="bg-white text-slate-900 p-4 rounded-xl font-mono text-xs space-y-2 border border-slate-300 shadow-sm"
            >
              <div className="text-center space-y-0.5">
                <p className="font-black text-sm uppercase tracking-wide">MULTISERVICE NAMBININA</p>
                <p className="text-[10px] text-slate-600">Reçu de Caisse • N° {lastCompletedTx.id}</p>
                <p className="text-[10px] text-slate-500">
                  {lastCompletedTx.dateString} à {lastCompletedTx.timeString}
                </p>
              </div>

              <div className="border-t border-b border-dashed border-slate-300 py-1.5 space-y-1">
                <p>Client : {lastCompletedTx.clientName}</p>
                {lastCompletedTx.clientPhone && <p>Tél : {lastCompletedTx.clientPhone}</p>}
                <p>Guichetier : {lastCompletedTx.cashierName}</p>
              </div>

              <div className="space-y-1 py-1">
                {lastCompletedTx.items.map((it, idx) => (
                  <div key={idx} className="flex justify-between">
                    <span className="truncate max-w-[180px]">
                      {it.quantity}x {it.taskName}
                    </span>
                    <span className="font-bold">{new Intl.NumberFormat('fr-FR').format(it.total)} {currency}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-dashed border-slate-300 pt-2 flex justify-between font-black text-sm">
                <span>TOTAL PAYÉ :</span>
                <span>{new Intl.NumberFormat('fr-FR').format(lastCompletedTx.totalAmount)} {currency}</span>
              </div>

              <div className="text-[10px] text-slate-600 pt-1 text-center border-t border-slate-200 mt-2">
                Règlement : ESPÈCES EN ARIARY (MGA)
                <br />
                Misaotra betsaka tamin'ny fandalovana!
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={() => window.print()}
                className="w-1/2 py-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-white text-xs font-bold flex items-center justify-center gap-1.5 transition border border-slate-300 dark:border-transparent"
              >
                <PrintIcon className="w-4 h-4" />
                <span>Imprimer Reçu</span>
              </button>
              <button
                onClick={() => setLastCompletedTx(null)}
                className="w-1/2 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black transition shadow-md shadow-emerald-500/20"
              >
                Nouvelle Vente
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
