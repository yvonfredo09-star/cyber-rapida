import React from 'react';
import { ShoppingCart, BarChart3, Users, Wrench, Camera } from 'lucide-react';

interface MobileBottomNavProps {
  activeTab: 'caisse' | 'compta' | 'clients' | 'taches' | 'archives';
  setActiveTab: (tab: 'caisse' | 'compta' | 'clients' | 'taches' | 'archives') => void;
  onOpenClosing: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({
  activeTab,
  setActiveTab,
  onOpenClosing,
}) => {
  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-slate-900/95 backdrop-blur-lg border-t border-slate-200 dark:border-slate-800 pb-[env(safe-area-inset-bottom)] transition-colors">
      <div className="grid grid-cols-5 items-center h-16 px-1">
        <button
          onClick={() => setActiveTab('caisse')}
          className={`flex flex-col items-center justify-center h-full gap-1 transition ${
            activeTab === 'caisse'
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <ShoppingCart className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Caisse</span>
        </button>

        <button
          onClick={() => setActiveTab('compta')}
          className={`flex flex-col items-center justify-center h-full gap-1 transition ${
            activeTab === 'compta'
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <BarChart3 className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Compta</span>
        </button>

        {/* Central High-Action Button: Capture du Soir */}
        <button
          onClick={onOpenClosing}
          className="flex flex-col items-center justify-center h-full gap-1 transition text-emerald-600 dark:text-emerald-400"
        >
          <div className="w-10 h-10 -mt-4 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 shadow-lg shadow-emerald-500/30 active:scale-95 transition">
            <Camera className="w-5 h-5 stroke-[2.5]" />
          </div>
          <span className="text-[10px] font-black text-emerald-700 dark:text-emerald-300">Soir 📸</span>
        </button>

        <button
          onClick={() => setActiveTab('clients')}
          className={`flex flex-col items-center justify-center h-full gap-1 transition ${
            activeTab === 'clients'
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Users className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Clients</span>
        </button>

        <button
          onClick={() => setActiveTab('taches')}
          className={`flex flex-col items-center justify-center h-full gap-1 transition ${
            activeTab === 'taches'
              ? 'text-emerald-600 dark:text-emerald-400 font-bold'
              : 'text-slate-500 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
          }`}
        >
          <Wrench className="w-5 h-5" />
          <span className="text-[10px] tracking-tight">Tâches</span>
        </button>
      </div>
    </div>
  );
};
