import React from 'react';
import { Camera, Clock, Smartphone, User, ShieldCheck, Sun, Moon } from 'lucide-react';
import { BusinessSettings } from '../types';
import { ServiceHoursStatus } from '../utils/serviceHours';
import { usePWAInstall } from '../hooks/usePWAInstall';

interface HeaderProps {
  settings: BusinessSettings;
  hoursStatus: ServiceHoursStatus;
  currentTimeString: string;
  activeTab: 'caisse' | 'compta' | 'clients' | 'taches' | 'archives';
  setActiveTab: (tab: 'caisse' | 'compta' | 'clients' | 'taches' | 'archives') => void;
  onOpenClosing: () => void;
  onOpenSettings: () => void;
  cashInDrawer: number;
  currency: string;
  isDark: boolean;
  onToggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  hoursStatus,
  currentTimeString,
  activeTab,
  setActiveTab,
  onOpenClosing,
  onOpenSettings,
  cashInDrawer,
  currency,
  isDark,
  onToggleTheme,
}) => {
  const { isInstallable, install } = usePWAInstall();

  return (
    <header className="sticky top-0 z-30 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 transition-colors">
      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2.5 flex items-center justify-between gap-4">
        {/* Brand Zone */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-white font-black text-lg shadow-md shadow-emerald-900/20">
            MN
          </div>
          <div>
            <h1 className="text-base font-bold text-slate-900 dark:text-white tracking-tight leading-none whitespace-nowrap">
              {settings.businessName}
            </h1>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 hidden sm:block leading-tight mt-0.5">
              Multiservice • Impressions • Photocopie • Scans • Reliure
            </p>
          </div>
        </div>

        {/* Status & Service Hours badge */}
        <div className="hidden md:flex items-center gap-3 bg-slate-100/80 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800/80 rounded-xl px-3 py-1.5 text-xs">
          <div className="flex items-center gap-2">
            <span
              className={`w-2.5 h-2.5 rounded-full ${
                hoursStatus.isOpen
                  ? hoursStatus.isClosingSoon
                    ? 'bg-amber-500 animate-pulse'
                    : 'bg-emerald-500'
                  : 'bg-rose-500'
              }`}
            />
            <span className="font-semibold text-slate-700 dark:text-slate-200">{hoursStatus.statusLabel}</span>
          </div>
          <span className="text-slate-300 dark:text-slate-600">|</span>
          <div className="flex items-center gap-1.5 text-slate-500 dark:text-slate-400 font-mono text-[11px]">
            <Clock className="w-3.5 h-3.5 text-slate-400" />
            <span>{settings.openingTime} - {settings.closingTime}</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-semibold ml-1">({currentTimeString})</span>
          </div>
        </div>

        {/* Quick Drawer & Action Zone */}
        <div className="flex items-center gap-2 shrink-0">
          {/* Day / Night Mode Toggle Button */}
          <button
            onClick={onToggleTheme}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-bold border border-slate-300 dark:border-slate-700/80 shadow-sm active:scale-95 transition-all"
            title={isDark ? 'Passer en Mode Jour (clair)' : 'Passer en Mode Nuit (sombre)'}
            aria-label="Basculer mode jour et nuit"
          >
            {isDark ? (
              <>
                <Sun className="w-4 h-4 text-amber-400 shrink-0" />
                <span className="text-[11px] font-bold text-amber-600 dark:text-amber-300">Mode Jour</span>
              </>
            ) : (
              <>
                <Moon className="w-4 h-4 text-indigo-600 shrink-0" />
                <span className="text-[11px] font-bold text-indigo-700 dark:text-indigo-300">Mode Nuit</span>
              </>
            )}
          </button>

          {/* Cash In Drawer Quick View */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs">
            <span className="text-slate-500 dark:text-slate-400">Tiroir Caisse:</span>
            <span className="font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
              {new Intl.NumberFormat('fr-FR').format(cashInDrawer)} {currency}
            </span>
          </div>

          {/* PWA Install Button if available */}
          {isInstallable && (
            <button
              onClick={install}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-100 dark:bg-sky-950/80 border border-sky-300 dark:border-sky-700/60 text-sky-700 dark:text-sky-300 hover:bg-sky-200 dark:hover:bg-sky-900/60 text-xs font-semibold transition-all whitespace-nowrap"
              title="Installer sur Android / PC"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>Installer</span>
            </button>
          )}

          {/* Evening Closing Manual Capture Button */}
          <button
            onClick={onOpenClosing}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/20 active:scale-95 transition-all whitespace-nowrap"
          >
            <Camera className="w-4 h-4 text-slate-950 stroke-[2.5]" />
            <span>Capture du Soir</span>
          </button>

          {/* Cashier / Settings trigger */}
          <button
            onClick={onOpenSettings}
            className="p-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-transparent transition-colors"
            title="Paramètres multiservice et horaires"
          >
            <User className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Navigation Tabs - Desktop & Tablet */}
      <div className="border-t border-slate-200 dark:border-slate-800/80 bg-slate-50/90 dark:bg-slate-950/40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between overflow-x-auto no-scrollbar py-1">
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              onClick={() => setActiveTab('caisse')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                activeTab === 'caisse'
                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-bold'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Caisse & Encaissement
            </button>
            <button
              onClick={() => setActiveTab('compta')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                activeTab === 'compta'
                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-bold'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Comptabilité Intégrée
            </button>
            <button
              onClick={() => setActiveTab('clients')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                activeTab === 'clients'
                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-bold'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Historique Clients
            </button>
            <button
              onClick={() => setActiveTab('taches')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                activeTab === 'taches'
                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-bold'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Gestion des Tâches (CRUD)
            </button>
            <button
              onClick={() => setActiveTab('archives')}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all whitespace-nowrap ${
                activeTab === 'archives'
                  ? 'bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30 font-bold'
                  : 'text-slate-600 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
              }`}
            >
              Bilans Archivés
            </button>
          </nav>

          <div className="text-[11px] text-slate-500 dark:text-slate-400 hidden md:flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Guichetier : <strong className="text-slate-800 dark:text-slate-200 font-medium">{settings.currentCashier}</strong></span>
          </div>
        </div>
      </div>
    </header>
  );
};
