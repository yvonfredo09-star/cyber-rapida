import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  TrendingDown,
  Plus,
  Trash2,
  Banknote,
  Receipt,
  X,
  CreditCard,
  Building,
  Printer,
  Copy,
  Folder,
  Coins,
} from 'lucide-react';
import { Transaction, Expense, PaymentMethod } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface AccountingViewProps {
  transactions: Transaction[];
  expenses: Expense[];
  onAddExpense: (exp: Omit<Expense, 'id' | 'timestamp' | 'dateString' | 'timeString'>) => void;
  onDeleteExpense: (id: string) => void;
  currency: string;
  openingCash: number;
  onUpdateOpeningCash: (amt: number) => void;
}

export const AccountingView: React.FC<AccountingViewProps> = ({
  transactions,
  expenses,
  onAddExpense,
  onDeleteExpense,
  currency,
  openingCash,
  onUpdateOpeningCash,
}) => {
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseDesc, setExpenseDesc] = useState('');
  const [expenseAmount, setExpenseAmount] = useState('');
  const [expenseCategory, setExpenseCategory] = useState<Expense['category']>('papier_encre');
  const [expensePaymentMethod, setExpensePaymentMethod] = useState<PaymentMethod>('especes');
  const [expenseBeneficiary, setExpenseBeneficiary] = useState('');
  const [editingOpeningFund, setEditingOpeningFund] = useState(false);
  const [openingCashInput, setOpeningCashInput] = useState(openingCash.toString());

  // Filter for today's data
  const todayStr = new Date().toISOString().split('T')[0];
  const todayTransactions = transactions.filter((t) => t.dateString === todayStr);
  const todayExpenses = expenses.filter((e) => e.dateString === todayStr);

  // Accounting calculations
  const totalRevenue = todayTransactions.reduce((acc, t) => acc + t.totalAmount, 0);

  const cashIn = todayTransactions
    .filter((t) => t.paymentMethod === 'especes' && t.paymentStatus === 'paye')
    .reduce((acc, t) => acc + t.totalAmount, 0);

  const creditIn = todayTransactions
    .filter((t) => t.paymentStatus === 'credit')
    .reduce((acc, t) => acc + t.totalAmount, 0);

  const cashExpenses = todayExpenses
    .filter((e) => e.paymentMethod === 'especes')
    .reduce((acc, e) => acc + e.amount, 0);

  const totalAllExpenses = todayExpenses.reduce((acc, e) => acc + e.amount, 0);

  // Current physical cash in drawer
  const currentCashInDrawer = openingCash + cashIn - cashExpenses;

  // Bureautique details
  const totalPagesCount = todayTransactions.reduce((acc, t) => {
    return (
      acc +
      t.items
        .filter((it) => it.category === 'impressions_copies' || it.category === 'scan_informatique')
        .reduce((sum, it) => sum + it.quantity, 0)
    );
  }, 0);


  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(expenseAmount) || 0;
    if (amountNum <= 0 || !expenseDesc.trim()) return;

    onAddExpense({
      description: expenseDesc.trim(),
      amount: amountNum,
      category: expenseCategory,
      paymentMethod: 'especes', // Strictly Ariary
      beneficiary: expenseBeneficiary.trim() || undefined,
    });

    setExpenseDesc('');
    setExpenseAmount('');
    setExpenseBeneficiary('');
    setIsExpenseModalOpen(false);
  };

  const saveOpeningFund = () => {
    const num = parseFloat(openingCashInput) || 0;
    onUpdateOpeningCash(num);
    setEditingOpeningFund(false);
  };

  return (
    <div className="space-y-6">
      {/* KPI Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Physical Cash Drawer Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 shadow-sm transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Tiroir Caisse (Ariary)
            </span>
            <div className="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 flex items-center justify-center">
              <Banknote className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
            {formatCurrency(currentCashInDrawer, currency)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/80 pt-1.5">
            <span>Fond d'ouverture :</span>
            {editingOpeningFund ? (
              <div className="flex items-center gap-1">
                <input
                  type="number"
                  value={openingCashInput}
                  onChange={(e) => setOpeningCashInput(e.target.value)}
                  className="w-20 px-1 py-0.5 bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-700 rounded text-xs font-mono text-slate-900 dark:text-white"
                />
                <button
                  onClick={saveOpeningFund}
                  className="px-1.5 py-0.5 bg-emerald-500 text-slate-950 rounded text-[10px] font-bold"
                >
                  OK
                </button>
              </div>
            ) : (
              <button
                onClick={() => setEditingOpeningFund(true)}
                className="font-mono text-slate-700 dark:text-slate-300 hover:text-emerald-600 dark:hover:text-emerald-400 underline"
                title="Modifier le fond de caisse"
              >
                {formatCurrency(openingCash, currency)}
              </button>
            )}
          </div>
        </div>

        {/* Total Chiffre d'Affaires */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 shadow-sm transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Recettes du Jour (CA)
            </span>
            <div className="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-600 dark:text-sky-400 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-slate-900 dark:text-white font-mono tabular-nums">
            {formatCurrency(totalRevenue, currency)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/80 pt-1.5">
            <span>{todayTransactions.length} transaction(s)</span>
            <span>~{totalPagesCount} pages traitées</span>
          </div>
        </div>

        {/* Dépenses du Jour */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 space-y-2 shadow-sm transition-colors">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
              Dépenses & Sorties
            </span>
            <div className="w-8 h-8 rounded-lg bg-rose-500/15 text-rose-600 dark:text-rose-400 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <p className="text-2xl font-black text-rose-600 dark:text-rose-400 font-mono tabular-nums">
            -{formatCurrency(totalAllExpenses, currency)}
          </p>
          <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 border-t border-slate-100 dark:border-slate-800/80 pt-1.5">
            <span>{todayExpenses.length} sortie(s) décaissée(s)</span>
            <button
              onClick={() => setIsExpenseModalOpen(true)}
              className="text-rose-600 dark:text-rose-400 hover:underline font-bold"
            >
              + Décaisser
            </button>
          </div>
        </div>
      </div>

      {/* Mode de Règlement : Exclusivement en Ariary */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4 shadow-sm transition-colors">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
            Flux de Caisse (Mode de règlement : Seulement en Ariary)
          </h3>
          <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
            Devise officielle : Ariary (Ar)
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
              <Banknote className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
              <span>Espèces en Ariary (Caisse physique)</span>
            </div>
            <p className="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono tabular-nums">
              {formatCurrency(cashIn, currency)}
            </p>
            <p className="text-[11px] text-slate-500">Règlements reçus au comptoir</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 space-y-1">
            <div className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
              <Coins className="w-3.5 h-3.5 text-amber-500" />
              <span>Total Décaissé pour Dépenses</span>
            </div>
            <p className="text-xl font-bold text-rose-600 dark:text-rose-400 font-mono tabular-nums">
              -{formatCurrency(cashExpenses, currency)}
            </p>
            <p className="text-[11px] text-slate-500">Papeterie, encre, électricité, fournitures</p>
          </div>
        </div>
      </div>

      {/* TWO COLUMNS: Dépenses du Jour + Grand Livre des Ventes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Expenses Table (5 cols on lg) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Receipt className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Sorties & Dépenses ({todayExpenses.length})
              </h3>
            </div>
            <button
              onClick={() => setIsExpenseModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-50 dark:bg-rose-500/20 hover:bg-rose-100 dark:hover:bg-rose-500/30 text-rose-700 dark:text-rose-300 text-xs font-bold transition border border-rose-200 dark:border-rose-500/30"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Ajouter Dépense</span>
            </button>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm transition-colors">
            {todayExpenses.length === 0 ? (
              <div className="p-6 text-center text-slate-500 text-xs">
                Aucune dépense enregistrée aujourd'hui.
              </div>
            ) : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {todayExpenses.map((exp) => (
                  <div key={exp.id} className="p-3 flex items-center justify-between gap-3 text-xs">
                    <div className="space-y-0.5">
                      <p className="font-semibold text-slate-800 dark:text-slate-200">{exp.description}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {exp.timeString} • {exp.category.replace('_', ' ')}
                        {exp.beneficiary ? ` • ${exp.beneficiary}` : ''}
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="font-mono font-bold text-rose-600 dark:text-rose-400 tabular-nums">
                        -{formatCurrency(exp.amount, currency)}
                      </span>
                      <button
                        onClick={() => onDeleteExpense(exp.id)}
                        className="p-1 text-slate-400 hover:text-rose-500"
                        title="Supprimer la dépense"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Unified Cash Journal (7 cols on lg) */}
        <div className="lg:col-span-7 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Grand Livre de Caisse du Jour ({todayTransactions.length} Ventes)
            </h3>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              Total Encaissé : {formatCurrency(totalRevenue, currency)}
            </span>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-sm transition-colors">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 dark:bg-slate-950/80 border-b border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400 text-[11px] font-semibold uppercase">
                    <th className="py-2.5 px-3">Heure</th>
                    <th className="py-2.5 px-3">Client</th>
                    <th className="py-2.5 px-3">Détail Services</th>
                    <th className="py-2.5 px-3">Paiement</th>
                    <th className="py-2.5 px-3 text-right">Montant</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/70">
                  {todayTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-500">
                        Aucun encaissement aujourd'hui.
                      </td>
                    </tr>
                  ) : (
                    todayTransactions.map((tx) => (
                      <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-mono text-slate-500 dark:text-slate-400">
                          {tx.timeString}
                        </td>
                        <td className="py-2.5 px-3">
                          <p className="font-semibold text-slate-800 dark:text-slate-200">{tx.clientName}</p>
                          {tx.clientPhone && (
                            <p className="text-[10px] text-slate-500 font-mono">{tx.clientPhone}</p>
                          )}
                        </td>
                        <td className="py-2.5 px-3">
                          <div className="space-y-0.5">
                            {tx.items.map((it, idx) => (
                              <span
                                key={idx}
                                className="inline-block bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-1.5 py-0.5 rounded text-[10px] text-slate-700 dark:text-slate-300 mr-1 mb-1"
                              >
                                {it.quantity}x {it.taskName}
                              </span>
                            ))}
                          </div>
                        </td>
                        <td className="py-2.5 px-3">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-100 dark:bg-emerald-500/20 text-emerald-700 dark:text-emerald-400 border border-emerald-300 dark:border-transparent">
                            Espèces (Ariary)
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-900 dark:text-white tabular-nums">
                          {formatCurrency(tx.totalAmount, currency)}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* MODAL: Add Expense */}
      {isExpenseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-sm p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">Enregistrer une Sortie de Caisse (Dépense en Ariary)</h3>
              <button
                onClick={() => setIsExpenseModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Motif de la dépense :
                </label>
                <input
                  type="text"
                  required
                  value={expenseDesc}
                  onChange={(e) => setExpenseDesc(e.target.value)}
                  placeholder="ex: Ramette papier A4, Encre toner, Connexion internet..."
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Montant ({currency}) :
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(e.target.value)}
                    placeholder="15000"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono text-rose-600 dark:text-rose-400 font-bold focus:outline-none focus:border-rose-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Catégorie :
                  </label>
                  <select
                    value={expenseCategory}
                    onChange={(e) => setExpenseCategory(e.target.value as Expense['category'])}
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                  >
                    <option value="papier_encre">Papier A4 & Encre / Toner</option>
                    <option value="electricite_internet">Électricité (Jirama) & Internet</option>
                    <option value="fournitures_bureau">Fournitures bureau</option>
                    <option value="maintenance">Maintenance imprimante</option>
                    <option value="transport">Transport / Déplacement</option>
                    <option value="loyer">Loyer Kiosque</option>
                    <option value="salaire">Salaire / Prélèvement</option>
                    <option value="autre">Autre dépense</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Mode de règlement :
                  </label>
                  <div className="w-full px-3 py-2 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-emerald-700 dark:text-emerald-400 font-bold flex items-center gap-1.5">
                    <Banknote className="w-3.5 h-3.5" />
                    <span>Espèces en Ariary</span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    Fournisseur / Bénéficiaire :
                  </label>
                  <input
                    type="text"
                    value={expenseBeneficiary}
                    onChange={(e) => setExpenseBeneficiary(e.target.value)}
                    placeholder="ex: Papeterie Centrale"
                    className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:border-rose-500"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setIsExpenseModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 text-xs font-bold transition"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold uppercase hover:bg-rose-500 transition shadow-sm"
                >
                  Enregistrer la dépense
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
