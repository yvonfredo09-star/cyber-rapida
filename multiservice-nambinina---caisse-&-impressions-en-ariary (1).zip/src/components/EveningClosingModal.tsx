import React, { useState, useRef, useMemo } from 'react';
import {
  Camera,
  X,
  Printer as PrintIcon,
  Banknote,
  Coins,
  ShieldCheck,
  Calendar,
  Clock,
  TrendingUp,
  TrendingDown,
  Copy,
  Check,
  Building,
  CreditCard,
} from 'lucide-react';
import { toPng } from 'html-to-image';
import { Transaction, Expense, DailyClosing, BusinessSettings, CashDenominations } from '../types';
import { formatCurrency } from '../utils/serviceHours';

interface EveningClosingModalProps {
  isOpen: boolean;
  onClose: () => void;
  transactions: Transaction[];
  expenses: Expense[];
  openingCash: number;
  settings: BusinessSettings;
  onSaveClosing: (closing: DailyClosing) => void;
  currency: string;
}

export const EveningClosingModal: React.FC<EveningClosingModalProps> = ({
  isOpen,
  onClose,
  transactions,
  expenses,
  openingCash,
  settings,
  onSaveClosing,
  currency,
}) => {
  const reportRef = useRef<HTMLDivElement>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const [copiedWhatsApp, setCopiedWhatsApp] = useState(false);
  const [closingNotes, setClosingNotes] = useState('');
  const [countedCashInput, setCountedCashInput] = useState<string>('');

  const todayStr = new Date().toISOString().split('T')[0];
  const now = new Date();
  const timeStr = now.toTimeString().split(' ')[0];

  const todayTransactions = useMemo(
    () => transactions.filter((t) => t.dateString === todayStr),
    [transactions, todayStr]
  );
  const todayExpenses = useMemo(
    () => expenses.filter((e) => e.dateString === todayStr),
    [expenses, todayStr]
  );

  // Accounting figures
  const cashIn = todayTransactions
    .filter((t) => t.paymentMethod === 'especes' && t.paymentStatus === 'paye')
    .reduce((sum, t) => sum + t.totalAmount, 0);

  const creditIn = todayTransactions
    .filter((t) => t.paymentStatus === 'credit')
    .reduce((sum, t) => sum + t.totalAmount, 0);

  const cashOutExpenses = todayExpenses
    .filter((e) => e.paymentMethod === 'especes')
    .reduce((sum, e) => sum + e.amount, 0);

  const totalAllExpenses = todayExpenses.reduce((sum, e) => sum + e.amount, 0);

  const theoreticalCash = openingCash + cashIn - cashOutExpenses;

  // Breakdown services
  let totalBureautiqueRevenue = 0;
  let totalFournituresRevenue = 0;
  let totalPagesCount = 0;
  let copiesCount = 0;
  let printsCount = 0;
  let scansCount = 0;
  let plastificationCount = 0;
  let reliureCount = 0;

  todayTransactions.forEach((tx) => {
    tx.items.forEach((item) => {
      if (item.category === 'fournitures') {
        totalFournituresRevenue += item.total;
      } else {
        totalBureautiqueRevenue += item.total;
        const nameLower = item.taskName.toLowerCase();
        if (nameLower.includes('copie')) {
          copiesCount += item.quantity;
          totalPagesCount += item.quantity;
        } else if (nameLower.includes('impression') || nameLower.includes('print')) {
          printsCount += item.quantity;
          totalPagesCount += item.quantity;
        } else if (nameLower.includes('scan')) {
          scansCount += item.quantity;
        } else if (nameLower.includes('plastif')) {
          plastificationCount += item.quantity;
        } else if (nameLower.includes('reliure')) {
          reliureCount += item.quantity;
        }
      }
    });
  });

  // Counted physical cash: defaults to theoreticalCash, or user can enter a custom total if there is a discrepancy
  const effectiveCountedCash =
    countedCashInput.trim() !== ''
      ? parseFloat(countedCashInput) || 0
      : theoreticalCash;
  const difference = effectiveCountedCash - theoreticalCash;

  const totalDayRevenue = totalBureautiqueRevenue + totalFournituresRevenue;
  const netProfitEstimate = totalDayRevenue - totalAllExpenses;

  // Manual Screen Capture Trigger via html-to-image
  const handleCaptureScreenshot = async () => {
    if (!reportRef.current) return;
    try {
      setIsCapturing(true);
      const dataUrl = await toPng(reportRef.current, {
        quality: 0.95,
        backgroundColor: '#020617',
        pixelRatio: 2, // High resolution for mobile sharing
      });

      // Trigger instant PNG download
      const link = document.createElement('a');
      link.download = `cloture_${settings.businessName.replace(/\s+/g, '_')}_${todayStr}_${timeStr.replace(/:/g, '')}.png`;
      link.href = dataUrl;
      link.click();

      // Also save to archive
      saveClosingToArchive(dataUrl);
    } catch (err) {
      console.error('Erreur lors de la capture d’écran', err);
    } finally {
      setIsCapturing(false);
    }
  };

  const saveClosingToArchive = (imageUri?: string) => {
    const closingRecord: DailyClosing = {
      id: `closing-${todayStr}-${Date.now().toString().slice(-4)}`,
      dateString: todayStr,
      closedAt: Date.now(),
      closedTimeString: timeStr,
      cashierName: settings.currentCashier,
      openingCash,
      totalCashIn: cashIn,
      totalCashOut: cashOutExpenses,
      theoreticalCash,
      countedCash: effectiveCountedCash,
      difference,
      totalCreditIn: creditIn,
      totalBureautiqueRevenue,
      totalFournituresRevenue,
      totalPagesCount,
      totalTransactionsCount: todayTransactions.length,
      totalExpenses: totalAllExpenses,
      netProfitEstimate,
      notes: closingNotes,
      denominations: undefined,
    };

    onSaveClosing(closingRecord);
  };

  // WhatsApp text export in Ariary
  const copyWhatsAppSummary = () => {
    const text = `📊 *CLÔTURE DE CAISSE MULTISERVICE NAMBININA*
🏢 *${settings.businessName}*
📅 Date : ${todayStr} à ${timeStr}
👤 Guichetier : ${settings.currentCashier}
━━━━━━━━━━━━━━━━━━
💰 *CAISSE PHYSIQUE ESPÈCES (ARIARY)*
• Fond du matin : ${formatCurrency(openingCash, currency)}
• Entrées Espèces : +${formatCurrency(cashIn, currency)}
• Dépenses Espèces : -${formatCurrency(cashOutExpenses, currency)}
👉 *Solde Théorique :* ${formatCurrency(theoreticalCash, currency)}
👉 *Solde Compté :* ${formatCurrency(effectiveCountedCash, currency)}
👉 *Écart de caisse :* ${difference >= 0 ? `+${difference}` : difference} ${currency}

📄 *ACTIVITÉ BUREAUTIQUE & COPIES*
• CA Bureautique : ${formatCurrency(totalBureautiqueRevenue, currency)}
• CA Fournitures : ${formatCurrency(totalFournituresRevenue, currency)}
• Photocopies : ${copiesCount} feuilles
• Impressions N&B & Couleur : ${printsCount} pages
• Scans / Numérisations : ${scansCount} docs
• Reliures : ${reliureCount} | Plastifications : ${plastificationCount}

🇲🇬 *RÈGLEMENTS (SEULEMENT EN ARIARY)*
• Espèces en Ariary : ${formatCurrency(cashIn, currency)}
• Crédits en cours : ${formatCurrency(creditIn, currency)}

📉 *DÉPENSES DU JOUR*
• Total décaissé : -${formatCurrency(totalAllExpenses, currency)}

✨ *BÉNÉFICE NET ESTIMÉ :* ${formatCurrency(netProfitEstimate, currency)}
━━━━━━━━━━━━━━━━━━
${closingNotes ? `📝 Note : ${closingNotes}\n` : ''}✅ Clôture certifiée manuelle Multiservice Nambinina`;

    navigator.clipboard.writeText(text);
    setCopiedWhatsApp(true);
    setTimeout(() => setCopiedWhatsApp(false), 2500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-4xl w-full max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Modal Top Bar */}
        <div className="p-4 sm:px-6 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 flex items-center justify-center">
              <Camera className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white tracking-tight leading-snug">
                Clôture de Caisse & Capture d'Écran du Soir
              </h2>
              <p className="text-xs text-slate-400">
                Génération manuelle du rapport officiel en Ariary ({currency})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white bg-slate-800/60 hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Scrollable */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-6 flex-1">
          {/* Vérification rapide du solde physique en caisse (Sans comptage de billet) */}
          <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center justify-center shrink-0">
                <Banknote className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Espèces en Caisse au Moment de la Clôture
                </h3>
                <p className="text-[11px] text-slate-400">
                  Solde théorique attendu : <strong className="text-emerald-400 font-mono">{formatCurrency(theoreticalCash, currency)}</strong>
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs text-slate-300 whitespace-nowrap">Solde physique compté :</label>
              <input
                type="number"
                placeholder={theoreticalCash.toString()}
                value={countedCashInput}
                onChange={(e) => setCountedCashInput(e.target.value)}
                className="w-36 px-3 py-1.5 bg-slate-900 border border-slate-700 rounded-xl text-xs font-mono font-bold text-emerald-400 focus:outline-none focus:border-emerald-500 text-right"
              />
              <span className="text-xs text-slate-400 font-bold">{currency}</span>
            </div>
          </div>

          {/* Section 2: THE OFFICIAL CLOSING REPORT CARD (Ready for screenshot) */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                Bordereau Officiel de Clôture (Zone de Capture 📸)
              </span>
              <span className="text-[11px] text-emerald-400 font-mono">
                Horodaté à {todayStr} • {timeStr}
              </span>
            </div>

            {/* This DOM container will be screenshotted by html-to-image */}
            <div
              ref={reportRef}
              id="closing-report-card"
              className="bg-slate-950 border-2 border-emerald-500/40 rounded-3xl p-5 sm:p-7 space-y-6 text-slate-100 shadow-2xl relative"
            >
              {/* Header Certificate */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-5 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-black text-xl shadow-lg">
                    MN
                  </div>
                  <div>
                    <h1 className="text-lg font-black tracking-tight text-white uppercase">
                      {settings.businessName}
                    </h1>
                    <p className="text-xs text-slate-400">{settings.slogan}</p>
                  </div>
                </div>

                <div className="text-left sm:text-right text-xs space-y-0.5">
                  <p className="font-bold text-emerald-400 uppercase tracking-wider text-[11px]">
                    ★ BORDEREAU DE CLÔTURE JOURNALIÈRE ★
                  </p>
                  <p className="text-slate-300 font-mono">
                    Date : <strong>{todayStr}</strong> • Heure : <strong>{timeStr}</strong>
                  </p>
                  <p className="text-slate-400">
                    Guichetier responsable : <strong className="text-white">{settings.currentCashier}</strong>
                  </p>
                </div>
              </div>

              {/* Grid 1: Caisse Physique Reconciliation */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                    1. Réconciliation de la Caisse Physique (Espèces en Ariary)
                  </span>
                  <span
                    className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${
                      difference === 0
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : difference > 0
                        ? 'bg-sky-500/20 text-sky-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {difference === 0
                      ? 'Caisse Parfaite'
                      : difference > 0
                      ? `Surplus (+${new Intl.NumberFormat('fr-FR').format(difference)} Ar)`
                      : `Manquant (${new Intl.NumberFormat('fr-FR').format(difference)} Ar)`}
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-slate-500 text-[11px]">Fond Matin</p>
                    <p className="text-sm font-bold font-mono text-white tabular-nums">
                      {formatCurrency(openingCash, currency)}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-slate-500 text-[11px]">Entrées Cash</p>
                    <p className="text-sm font-bold font-mono text-emerald-400 tabular-nums">
                      +{formatCurrency(cashIn, currency)}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800">
                    <p className="text-slate-500 text-[11px]">Dépenses Cash</p>
                    <p className="text-sm font-bold font-mono text-rose-400 tabular-nums">
                      -{formatCurrency(cashOutExpenses, currency)}
                    </p>
                  </div>
                  <div className="p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/40">
                    <p className="text-emerald-400 text-[11px] font-bold">Solde Théorique</p>
                    <p className="text-sm font-black font-mono text-emerald-300 tabular-nums">
                      {formatCurrency(theoreticalCash, currency)}
                    </p>
                  </div>
                </div>
              </div>

              {/* Grid 2: Bureautique & Fournitures Overview */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Bureautique breakdown */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
                  <h4 className="font-bold text-slate-300 uppercase text-[11px] flex items-center justify-between">
                    <span>2. Activité Bureautique & Copies</span>
                    <span className="text-emerald-400 font-mono">
                      {formatCurrency(totalBureautiqueRevenue, currency)}
                    </span>
                  </h4>
                  <div className="space-y-1.5 pt-1 text-slate-400">
                    <div className="flex justify-between">
                      <span>• Photocopies A4 :</span>
                      <strong className="text-white font-mono">{copiesCount} feuilles</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Impressions (N&B / Couleur) :</span>
                      <strong className="text-white font-mono">{printsCount} pages</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Scans & Numérisations :</span>
                      <strong className="text-white font-mono">{scansCount} docs</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Reliures & Plastifications :</span>
                      <strong className="text-white font-mono">{reliureCount + plastificationCount} pièces</strong>
                    </div>
                    <div className="flex justify-between border-t border-slate-800 pt-1 text-slate-300 font-semibold">
                      <span>Volume papier estimé :</span>
                      <span className="font-mono text-white">~{totalPagesCount} pages</span>
                    </div>
                  </div>
                </div>

                {/* Fournitures & Règlements en Ariary */}
                <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-2 text-xs">
                  <h4 className="font-bold text-slate-300 uppercase text-[11px] flex items-center justify-between">
                    <span>3. Fournitures & Dettes en Ariary</span>
                    <span className="text-sky-400 font-mono">
                      {formatCurrency(totalFournituresRevenue, currency)}
                    </span>
                  </h4>
                  <div className="space-y-1.5 pt-1 text-slate-400">
                    <div className="flex justify-between">
                      <span>• Vente Fournitures / Chemises :</span>
                      <strong className="text-sky-300 font-mono">{formatCurrency(totalFournituresRevenue, currency)}</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Mode de règlement :</span>
                      <strong className="text-emerald-400 font-mono">Strictement en Ariary</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>• Ventes à crédit restant dû :</span>
                      <strong className="text-amber-300 font-mono">{formatCurrency(creditIn, currency)}</strong>
                    </div>
                    <div className="flex justify-between border-t border-slate-800 pt-1 text-slate-300 font-semibold">
                      <span>Total Recettes Ventes :</span>
                      <span className="font-mono text-white">{formatCurrency(totalDayRevenue, currency)}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Grid 3: Dépenses justifiées & Net Final */}
              <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold uppercase text-[11px] text-slate-300">
                    4. Dépenses Décaissées du Jour ({todayExpenses.length})
                  </span>
                  <span className="font-mono font-bold text-rose-400">
                    -{formatCurrency(totalAllExpenses, currency)}
                  </span>
                </div>
                {todayExpenses.length > 0 ? (
                  <div className="space-y-1 max-h-28 overflow-y-auto pr-1">
                    {todayExpenses.map((e) => (
                      <div
                        key={e.id}
                        className="flex justify-between text-[11px] text-slate-400 border-b border-slate-800/60 py-0.5"
                      >
                        <span className="truncate pr-2">
                          • {e.description} ({e.paymentMethod.replace('_', ' ')})
                        </span>
                        <span className="font-mono font-semibold text-rose-400 shrink-0">
                          {formatCurrency(e.amount, currency)}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-500 italic text-[11px]">Aucune dépense décaissée.</p>
                )}
              </div>

              {/* Bottom Grand Total Box */}
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950/60 to-slate-900 border border-emerald-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <p className="text-xs uppercase font-bold text-emerald-400">
                    Bilan Net d'Exploitation du Jour
                  </p>
                  <p className="text-[11px] text-slate-400">
                    Total Recettes (Bureautique + Fournitures) - Dépenses
                  </p>
                </div>
                <div className="text-left sm:text-right">
                  <p className="text-2xl font-black font-mono text-emerald-300 tabular-nums">
                    {formatCurrency(netProfitEstimate, currency)}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono">
                    {todayTransactions.length} transactions traitées avec succès
                  </p>
                </div>
              </div>

              {/* Signature stamp */}
              <div className="pt-2 flex justify-between items-center text-[10px] text-slate-500 border-t border-slate-800/80">
                <span>MultiCaisse POS System • Madagascar Kiosk Edition</span>
                <span>Signature Guichetier : ____________________</span>
              </div>
            </div>
          </div>

          {/* Notes for closing */}
          <div>
            <label className="text-xs font-semibold text-slate-300 block mb-1">
              Remarque de fin de service / Note pour le patron :
            </label>
            <input
              type="text"
              value={closingNotes}
              onChange={(e) => setClosingNotes(e.target.value)}
              placeholder="ex: Ramette papier presque finie, toner encre changé..."
              className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Modal Footer: Action Buttons */}
        <div className="p-4 sm:px-6 bg-slate-950 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={copyWhatsAppSummary}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
            >
              {copiedWhatsApp ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  <span className="text-emerald-400">Copié dans le presse-papier !</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  <span>Copier pour WhatsApp</span>
                </>
              )}
            </button>

            <button
              onClick={() => window.print()}
              className="hidden sm:flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold transition"
            >
              <PrintIcon className="w-4 h-4" />
              <span>Imprimer</span>
            </button>
          </div>

          {/* PRIMARY BUTTON: Take Manual Screenshot PNG */}
          <div className="flex items-center gap-2">
            <button
              disabled={isCapturing}
              onClick={handleCaptureScreenshot}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/25 active:scale-95 transition"
            >
              <Camera className="w-4 h-4 stroke-[3]" />
              <span>
                {isCapturing ? 'Capture en cours...' : '📸 Prendre la Capture d’écran (PNG)'}
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
