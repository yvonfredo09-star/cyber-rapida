export type ServiceCategory = 'impressions_copies' | 'scan_informatique' | 'finition_reliure' | 'fournitures' | 'autre';

export type PaymentMethod = 'especes' | 'credit';

export interface TaskType {
  id: string;
  name: string;
  category: ServiceCategory;
  unitPrice: number; // en Ariary (Ar)
  unitCost: number;  // Coût estimé (papier, toner, etc.) en Ariary
  unitLabel: string; // "page", "feuille", "document", "pièce", "heure"
  icon: string;
  color: string;
  active: boolean;
}

export interface TransactionItem {
  taskTypeId: string;
  taskName: string;
  category: ServiceCategory;
  unitPrice: number;
  quantity: number;
  total: number;
}

export interface Transaction {
  id: string;
  timestamp: number;
  dateString: string; // YYYY-MM-DD
  timeString: string; // HH:MM:SS
  clientName: string;
  clientPhone?: string;
  items: TransactionItem[];
  subtotal: number;
  discount: number;
  totalAmount: number;
  paymentMethod: PaymentMethod;
  paymentStatus: 'paye' | 'credit' | 'annule';
  notes?: string;
  cashierName?: string;
}

export interface Expense {
  id: string;
  timestamp: number;
  dateString: string;
  timeString: string;
  category: 'papier_encre' | 'electricite_internet' | 'fournitures_bureau' | 'loyer' | 'maintenance' | 'salaire' | 'transport' | 'autre';
  description: string;
  amount: number;
  paymentMethod: PaymentMethod;
  beneficiary?: string;
}

// Coupures de billets et pièces en Ariary (Madagascar)
export interface CashDenominations {
  b20000: number; // Billets de 20 000 Ar
  b10000: number; // Billets de 10 000 Ar
  b5000: number;  // Billets de 5 000 Ar
  b2000: number;  // Billets de 2 000 Ar
  b1000: number;  // Billets de 1 000 Ar
  b500: number;   // Billets de 500 Ar
  b200: number;   // Billets de 200 Ar
  b100: number;   // Billets de 100 Ar
  c50: number;    // Pièces de 50 Ar
  c20: number;    // Pièces de 20 Ar
}

export interface DailyClosing {
  id: string;
  dateString: string;
  closedAt: number;
  closedTimeString: string;
  cashierName: string;
  openingCash: number;
  totalCashIn: number;
  totalCashOut: number;
  theoreticalCash: number;
  countedCash: number;
  difference: number;
  totalCreditIn: number;
  totalBureautiqueRevenue: number;
  totalFournituresRevenue: number;
  totalPagesCount: number;
  totalTransactionsCount: number;
  totalExpenses: number;
  netProfitEstimate: number;
  notes?: string;
  denominations?: CashDenominations;
}

export interface BusinessSettings {
  businessName: string;
  slogan: string;
  phone: string;
  address: string;
  currency: string; // "Ar" ou "Ariary"
  openingTime: string; // e.g. "07:30"
  closingTime: string; // e.g. "19:00"
  daysOpen: string[];
  initialCashDefault: number;
  currentCashier: string;
}

export interface ClientSummary {
  name: string;
  phone?: string;
  totalSpent: number;
  totalTransactions: number;
  debtBalance: number;
  lastVisit: string;
  lastVisitTimestamp: number;
}
