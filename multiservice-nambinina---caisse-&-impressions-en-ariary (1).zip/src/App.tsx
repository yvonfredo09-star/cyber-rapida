import React, { useState, useEffect, useMemo } from 'react';
import {
  loadTasks,
  saveTasks,
  loadTransactions,
  saveTransactions,
  loadExpenses,
  saveExpenses,
  loadClosings,
  saveClosings,
  loadSettings,
  saveSettings,
  getTodayOpeningCash,
  setTodayOpeningCash,
  DEFAULT_TASKS,
} from './services/storage';
import { TaskType, Transaction, Expense, DailyClosing, BusinessSettings, PaymentMethod } from './types';
import { getServiceHoursStatus } from './utils/serviceHours';
import { Header } from './components/Header';
import { ServiceHoursBanner } from './components/ServiceHoursBanner';
import { POSRegister } from './components/POSRegister';
import { TasksManager } from './components/TasksManager';
import { AccountingView } from './components/AccountingView';
import { ClientsHistoryView } from './components/ClientsHistoryView';
import { ArchivesView } from './components/ArchivesView';
import { EveningClosingModal } from './components/EveningClosingModal';
import { SettingsModal } from './components/SettingsModal';
import { MobileBottomNav } from './components/MobileBottomNav';

export default function App() {
  const [tasks, setTasks] = useState<TaskType[]>(() => loadTasks());
  const [transactions, setTransactions] = useState<Transaction[]>(() => loadTransactions());
  const [expenses, setExpenses] = useState<Expense[]>(() => loadExpenses());
  const [closings, setClosings] = useState<DailyClosing[]>(() => loadClosings());
  const [settings, setSettings] = useState<BusinessSettings>(() => loadSettings());
  const [openingCash, setOpeningCash] = useState<number>(() =>
    getTodayOpeningCash(settings.initialCashDefault)
  );

  const [activeTab, setActiveTab] = useState<'caisse' | 'compta' | 'clients' | 'taches' | 'archives'>('caisse');
  const [isClosingModalOpen, setIsClosingModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);

  // Day / Night Theme Mode
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    try {
      const saved = localStorage.getItem('nambinina_theme');
      if (saved === 'light' || saved === 'dark') return saved;
    } catch (e) {}
    return 'dark';
  });

  useEffect(() => {
    try {
      if (theme === 'dark') {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
      localStorage.setItem('nambinina_theme', theme);
    } catch (e) {}
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Real-time clock
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const currentTimeString = currentTime.toTimeString().split(' ')[0];
  const hoursStatus = useMemo(
    () => getServiceHoursStatus(settings, currentTime),
    [settings, currentTime]
  );

  // Cash in drawer computation
  const todayStr = currentTime.toISOString().split('T')[0];
  const cashInDrawer = useMemo(() => {
    const cashIn = transactions
      .filter((t) => t.dateString === todayStr && t.paymentMethod === 'especes' && t.paymentStatus === 'paye')
      .reduce((sum, t) => sum + t.totalAmount, 0);

    const cashOut = expenses
      .filter((e) => e.dateString === todayStr && e.paymentMethod === 'especes')
      .reduce((sum, e) => sum + e.amount, 0);

    return openingCash + cashIn - cashOut;
  }, [transactions, expenses, todayStr, openingCash]);

  // Clients list for POS auto-complete
  const clientsList = useMemo(() => {
    const set = new Map<string, { name: string; phone?: string }>();
    transactions.forEach((tx) => {
      if (tx.clientName && tx.clientName !== 'Client Comptoir') {
        set.set(tx.clientName, { name: tx.clientName, phone: tx.clientPhone });
      }
    });
    return Array.from(set.values());
  }, [transactions]);

  // Handlers for Transactions
  const handleAddTransaction = (
    txData: Omit<Transaction, 'id' | 'timestamp' | 'dateString' | 'timeString'>
  ) => {
    const now = new Date();
    const newTx: Transaction = {
      id: `TX-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      dateString: now.toISOString().split('T')[0],
      timeString: now.toTimeString().split(' ')[0],
      ...txData,
    };
    const updated = [newTx, ...transactions];
    setTransactions(updated);
    saveTransactions(updated);
  };

  const handleSettleDebt = (clientName: string, method: PaymentMethod) => {
    const now = new Date();
    const updated = transactions.map((t) => {
      if (t.clientName.trim() === clientName && t.paymentStatus === 'credit') {
        return {
          ...t,
          paymentStatus: 'paye' as const,
          paymentMethod: method,
          notes: `${t.notes ? t.notes + ' • ' : ''}Dette réglée le ${now.toISOString().split('T')[0]} (${method})`,
        };
      }
      return t;
    });
    setTransactions(updated);
    saveTransactions(updated);
  };

  // Handlers for Expenses
  const handleAddExpense = (
    expData: Omit<Expense, 'id' | 'timestamp' | 'dateString' | 'timeString'>
  ) => {
    const now = new Date();
    const newExp: Expense = {
      id: `EXP-${Date.now().toString().slice(-6)}`,
      timestamp: Date.now(),
      dateString: now.toISOString().split('T')[0],
      timeString: now.toTimeString().split(' ')[0],
      ...expData,
    };
    const updated = [newExp, ...expenses];
    setExpenses(updated);
    saveExpenses(updated);
  };

  const handleDeleteExpense = (id: string) => {
    const updated = expenses.filter((e) => e.id !== id);
    setExpenses(updated);
    saveExpenses(updated);
  };

  // Handlers for Tasks CRUD
  const handleAddTask = (taskData: Omit<TaskType, 'id'>) => {
    const newTask: TaskType = {
      id: `task-${Date.now()}`,
      ...taskData,
    };
    const updated = [...tasks, newTask];
    setTasks(updated);
    saveTasks(updated);
  };

  const handleUpdateTask = (task: TaskType) => {
    const updated = tasks.map((t) => (t.id === task.id ? task : t));
    setTasks(updated);
    saveTasks(updated);
  };

  const handleDeleteTask = (id: string) => {
    const updated = tasks.filter((t) => t.id !== id);
    setTasks(updated);
    saveTasks(updated);
  };

  const handleResetTasksDefaults = () => {
    if (window.confirm('Réinitialiser la liste des services aux valeurs par défaut ?')) {
      setTasks(DEFAULT_TASKS);
      saveTasks(DEFAULT_TASKS);
    }
  };

  // Handlers for Closings & Settings
  const handleSaveClosing = (closing: DailyClosing) => {
    const updated = [closing, ...closings];
    setClosings(updated);
    saveClosings(updated);
  };

  const handleUpdateClosing = (updatedClosing: DailyClosing) => {
    const updated = closings.map((c) => (c.id === updatedClosing.id ? updatedClosing : c));
    setClosings(updated);
    saveClosings(updated);
  };

  const handleDeleteClosing = (id: string) => {
    const updated = closings.filter((c) => c.id !== id);
    setClosings(updated);
    saveClosings(updated);
  };

  const handleSaveSettings = (newSettings: BusinessSettings) => {
    setSettings(newSettings);
    saveSettings(newSettings);
  };

  const handleUpdateOpeningCash = (amount: number) => {
    setOpeningCash(amount);
    setTodayOpeningCash(amount);
  };

  // Data Export & Import
  const handleExportData = () => {
    const fullBackup = {
      version: '1.0',
      exportDate: new Date().toISOString(),
      settings,
      tasks,
      transactions,
      expenses,
      closings,
    };
    const blob = new Blob([JSON.stringify(fullBackup, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup_multicaisse_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.tasks) {
          setTasks(parsed.tasks);
          saveTasks(parsed.tasks);
        }
        if (parsed.transactions) {
          setTransactions(parsed.transactions);
          saveTransactions(parsed.transactions);
        }
        if (parsed.expenses) {
          setExpenses(parsed.expenses);
          saveExpenses(parsed.expenses);
        }
        if (parsed.closings) {
          setClosings(parsed.closings);
          saveClosings(parsed.closings);
        }
        if (parsed.settings) {
          setSettings(parsed.settings);
          saveSettings(parsed.settings);
        }
        alert('Données restaurées avec succès !');
      } catch (err) {
        alert('Erreur lors de la lecture du fichier de sauvegarde.');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans pb-20 md:pb-8 transition-colors duration-200">
      {/* Header with Navigation and Quick Cash Drawer Status */}
      <Header
        settings={settings}
        hoursStatus={hoursStatus}
        currentTimeString={currentTimeString}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenClosing={() => setIsClosingModalOpen(true)}
        onOpenSettings={() => setIsSettingsModalOpen(true)}
        cashInDrawer={cashInDrawer}
        currency={settings.currency}
        isDark={theme === 'dark'}
        onToggleTheme={toggleTheme}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 sm:py-6 space-y-5">
        {/* Prominent Operating Hours & Kiosk Live Status Banner */}
        <ServiceHoursBanner
          settings={settings}
          status={hoursStatus}
          currentTimeString={currentTimeString}
          onEditHours={() => setIsSettingsModalOpen(true)}
        />

        {/* Tab Routing */}
        {activeTab === 'caisse' && (
          <POSRegister
            tasks={tasks}
            onAddTransaction={handleAddTransaction}
            currency={settings.currency}
            cashierName={settings.currentCashier}
            clientsList={clientsList}
          />
        )}

        {activeTab === 'compta' && (
          <AccountingView
            transactions={transactions}
            expenses={expenses}
            onAddExpense={handleAddExpense}
            onDeleteExpense={handleDeleteExpense}
            currency={settings.currency}
            openingCash={openingCash}
            onUpdateOpeningCash={handleUpdateOpeningCash}
          />
        )}

        {activeTab === 'clients' && (
          <ClientsHistoryView
            transactions={transactions}
            onSettleDebt={handleSettleDebt}
            currency={settings.currency}
          />
        )}

        {activeTab === 'taches' && (
          <TasksManager
            tasks={tasks}
            onAddTask={handleAddTask}
            onUpdateTask={handleUpdateTask}
            onDeleteTask={handleDeleteTask}
            onResetDefaults={handleResetTasksDefaults}
            currency={settings.currency}
          />
        )}

        {activeTab === 'archives' && (
          <ArchivesView
            closings={closings}
            currency={settings.currency}
            onUpdateClosing={handleUpdateClosing}
            onDeleteClosing={handleDeleteClosing}
          />
        )}
      </main>

      {/* Evening Closing Modal (Manual Screenshot capture) */}
      <EveningClosingModal
        isOpen={isClosingModalOpen}
        onClose={() => setIsClosingModalOpen(false)}
        transactions={transactions}
        expenses={expenses}
        openingCash={openingCash}
        settings={settings}
        onSaveClosing={handleSaveClosing}
        currency={settings.currency}
      />

      {/* Settings & Business Hours Modal */}
      <SettingsModal
        isOpen={isSettingsModalOpen}
        onClose={() => setIsSettingsModalOpen(false)}
        settings={settings}
        onSaveSettings={handleSaveSettings}
        onExportData={handleExportData}
        onImportData={handleImportData}
        isDark={theme === 'dark'}
        onToggleTheme={toggleTheme}
      />

      {/* Mobile Bottom Navigation Bar (Android Touch Optimized) */}
      <MobileBottomNav
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenClosing={() => setIsClosingModalOpen(true)}
      />
    </div>
  );
}
