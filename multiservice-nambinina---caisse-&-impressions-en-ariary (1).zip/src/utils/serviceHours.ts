import { BusinessSettings } from '../types';

export interface ServiceHoursStatus {
  isOpen: boolean;
  statusLabel: string;
  timeRemainingText: string;
  closingTimeFormatted: string;
  openingTimeFormatted: string;
  isClosingSoon: boolean; // within 30 mins
}

export function getServiceHoursStatus(settings: BusinessSettings, now: Date = new Date()): ServiceHoursStatus {
  const [openHour, openMin] = settings.openingTime.split(':').map(Number);
  const [closeHour, closeMin] = settings.closingTime.split(':').map(Number);

  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const openMinutes = openHour * 60 + openMin;
  const closeMinutes = closeHour * 60 + closeMin;

  const dayNames = ['Dimanche', 'Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'];
  const todayName = dayNames[now.getDay()];
  const isDayOpen = settings.daysOpen.includes(todayName);

  if (!isDayOpen) {
    return {
      isOpen: false,
      statusLabel: 'FERMÉ AUJOURD’HUI',
      timeRemainingText: 'Jour de repos',
      closingTimeFormatted: settings.closingTime,
      openingTimeFormatted: settings.openingTime,
      isClosingSoon: false,
    };
  }

  if (currentMinutes < openMinutes) {
    const diff = openMinutes - currentMinutes;
    const hours = Math.floor(diff / 60);
    const mins = diff % 60;
    return {
      isOpen: false,
      statusLabel: 'FERMÉ ACTUELLEMENT',
      timeRemainingText: `Ouvre à ${settings.openingTime} (dans ${hours > 0 ? `${hours}h ` : ''}${mins}min)`,
      closingTimeFormatted: settings.closingTime,
      openingTimeFormatted: settings.openingTime,
      isClosingSoon: false,
    };
  }

  if (currentMinutes >= closeMinutes) {
    return {
      isOpen: false,
      statusLabel: 'FERMÉ (SERVICE TERMINÉ)',
      timeRemainingText: `Heure de clôture dépassée (${settings.closingTime})`,
      closingTimeFormatted: settings.closingTime,
      openingTimeFormatted: settings.openingTime,
      isClosingSoon: false,
    };
  }

  // Currently open
  const diff = closeMinutes - currentMinutes;
  const hours = Math.floor(diff / 60);
  const mins = diff % 60;
  const isClosingSoon = diff <= 45;

  return {
    isOpen: true,
    statusLabel: isClosingSoon ? 'FERMETURE PROCHE' : 'OUVERT EN DIRECT',
    timeRemainingText: `Ferme dans ${hours > 0 ? `${hours}h ` : ''}${mins}min`,
    closingTimeFormatted: settings.closingTime,
    openingTimeFormatted: settings.openingTime,
    isClosingSoon,
  };
}

export function formatCurrency(amount: number, currency: string = 'Ar'): string {
  const formatted = new Intl.NumberFormat('fr-FR').format(Math.round(amount));
  return `${formatted} ${currency}`;
}

export function formatNumber(amount: number): string {
  return new Intl.NumberFormat('fr-FR').format(Math.round(amount));
}
