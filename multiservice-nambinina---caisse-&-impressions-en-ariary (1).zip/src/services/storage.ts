import { TaskType, Transaction, Expense, DailyClosing, BusinessSettings } from '../types';

export const DEFAULT_TASKS: TaskType[] = [
  {
    id: 'task-print-bw',
    name: 'Impression N&B A4',
    category: 'impressions_copies',
    unitPrice: 300,
    unitCost: 80,
    unitLabel: 'page',
    icon: 'Printer',
    color: 'emerald',
    active: true,
  },
  {
    id: 'task-print-color',
    name: 'Impression Couleur A4',
    category: 'impressions_copies',
    unitPrice: 1200,
    unitCost: 350,
    unitLabel: 'page',
    icon: 'FileSpreadsheet',
    color: 'sky',
    active: true,
  },
  {
    id: 'task-copy-recto',
    name: 'Photocopie A4 Recto',
    category: 'impressions_copies',
    unitPrice: 100,
    unitCost: 40,
    unitLabel: 'feuille',
    icon: 'Copy',
    color: 'teal',
    active: true,
  },
  {
    id: 'task-copy-verso',
    name: 'Photocopie Recto-Verso',
    category: 'impressions_copies',
    unitPrice: 200,
    unitCost: 70,
    unitLabel: 'feuille',
    icon: 'Files',
    color: 'indigo',
    active: true,
  },
  {
    id: 'task-scan-pdf',
    name: 'Numérisation / Scan PDF vers Clé ou Mail',
    category: 'scan_informatique',
    unitPrice: 500,
    unitCost: 0,
    unitLabel: 'doc',
    icon: 'Scan',
    color: 'blue',
    active: true,
  },
  {
    id: 'task-saisie-cv',
    name: 'Saisie Document / CV / Mémoire',
    category: 'scan_informatique',
    unitPrice: 1500,
    unitCost: 0,
    unitLabel: 'page',
    icon: 'FileText',
    color: 'purple',
    active: true,
  },
  {
    id: 'task-plastification',
    name: 'Plastification A4',
    category: 'finition_reliure',
    unitPrice: 1500,
    unitCost: 500,
    unitLabel: 'pièce',
    icon: 'ShieldCheck',
    color: 'amber',
    active: true,
  },
  {
    id: 'task-reliure',
    name: 'Reliure Spirale A4',
    category: 'finition_reliure',
    unitPrice: 3000,
    unitCost: 800,
    unitLabel: 'document',
    icon: 'BookOpen',
    color: 'rose',
    active: true,
  },
  {
    id: 'task-print-photo',
    name: 'Tirage Photo 10x15 cm Glacé',
    category: 'impressions_copies',
    unitPrice: 2000,
    unitCost: 600,
    unitLabel: 'photo',
    icon: 'Printer',
    color: 'cyan',
    active: true,
  },
  {
    id: 'task-fourniture-chemise',
    name: 'Chemise Carton / Pochette Dossier',
    category: 'fournitures',
    unitPrice: 800,
    unitCost: 400,
    unitLabel: 'pièce',
    icon: 'Folder',
    color: 'yellow',
    active: true,
  },
  {
    id: 'task-fourniture-enveloppe',
    name: 'Enveloppe A4 Kraft',
    category: 'fournitures',
    unitPrice: 500,
    unitCost: 200,
    unitLabel: 'pièce',
    icon: 'Mail',
    color: 'slate',
    active: true,
  },
  {
    id: 'task-fourniture-stylo',
    name: 'Stylo à bille / Fourniture',
    category: 'fournitures',
    unitPrice: 600,
    unitCost: 300,
    unitLabel: 'pièce',
    icon: 'FileText',
    color: 'orange',
    active: true,
  },
];

export const DEFAULT_SETTINGS: BusinessSettings = {
  businessName: 'Multiservice Nambinina',
  slogan: 'Photocopies • Impressions N&B & Couleur • Scans • Plastification • Reliure',
  phone: '034 00 000 00',
  address: 'Analakely / Antananarivo',
  currency: 'Ar',
  openingTime: '07:30',
  closingTime: '19:00',
  daysOpen: ['Lundi', 'Mardi', 'Mercredi', 'Jeudi', 'Vendredi', 'Samedi'],
  initialCashDefault: 50000, // 50 000 Ar
  currentCashier: 'Gérant / Caissier',
};

const getTodayString = () => {
  const d = new Date();
  return d.toISOString().split('T')[0];
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-101',
    timestamp: Date.now() - 1000 * 60 * 180,
    dateString: getTodayString(),
    timeString: '08:15:20',
    clientName: 'Rakoto Jean',
    clientPhone: '034 12 345 67',
    items: [
      {
        taskTypeId: 'task-copy-recto',
        taskName: 'Photocopie A4 Recto',
        category: 'impressions_copies',
        unitPrice: 100,
        quantity: 15,
        total: 1500,
      },
      {
        taskTypeId: 'task-plastification',
        taskName: 'Plastification A4',
        category: 'finition_reliure',
        unitPrice: 1500,
        quantity: 1,
        total: 1500,
      },
    ],
    subtotal: 3000,
    discount: 0,
    totalAmount: 3000,
    paymentMethod: 'especes',
    paymentStatus: 'paye',
    notes: 'Copies CIN et certificat',
    cashierName: 'Caissier',
  },
  {
    id: 'tx-102',
    timestamp: Date.now() - 1000 * 60 * 140,
    dateString: getTodayString(),
    timeString: '09:10:30',
    clientName: 'Rasoa Marie',
    clientPhone: '032 98 765 43',
    items: [
      {
        taskTypeId: 'task-print-bw',
        taskName: 'Impression N&B A4',
        category: 'impressions_copies',
        unitPrice: 300,
        quantity: 25,
        total: 7500,
      },
      {
        taskTypeId: 'task-reliure',
        taskName: 'Reliure Spirale A4',
        category: 'finition_reliure',
        unitPrice: 3000,
        quantity: 1,
        total: 3000,
      },
    ],
    subtotal: 10500,
    discount: 0,
    totalAmount: 10500,
    paymentMethod: 'especes',
    paymentStatus: 'paye',
    notes: 'Rapport de stage',
    cashierName: 'Caissier',
  },
  {
    id: 'tx-103',
    timestamp: Date.now() - 1000 * 60 * 80,
    dateString: getTodayString(),
    timeString: '10:45:12',
    clientName: 'Andry R.',
    clientPhone: '033 45 678 90',
    items: [
      {
        taskTypeId: 'task-scan-pdf',
        taskName: 'Numérisation / Scan PDF',
        category: 'scan_informatique',
        unitPrice: 500,
        quantity: 4,
        total: 2000,
      },
      {
        taskTypeId: 'task-print-color',
        taskName: 'Impression Couleur A4',
        category: 'impressions_copies',
        unitPrice: 1200,
        quantity: 3,
        total: 3600,
      },
    ],
    subtotal: 5600,
    discount: 0,
    totalAmount: 5600,
    paymentMethod: 'especes',
    paymentStatus: 'paye',
    cashierName: 'Caissier',
  },
  {
    id: 'tx-104',
    timestamp: Date.now() - 1000 * 60 * 25,
    dateString: getTodayString(),
    timeString: '11:30:00',
    clientName: 'Bureau Voisin (M. Hery)',
    clientPhone: '034 55 667 78',
    items: [
      {
        taskTypeId: 'task-copy-verso',
        taskName: 'Photocopie Recto-Verso',
        category: 'impressions_copies',
        unitPrice: 200,
        quantity: 20,
        total: 4000,
      },
    ],
    subtotal: 4000,
    discount: 0,
    totalAmount: 4000,
    paymentMethod: 'especes',
    paymentStatus: 'paye',
    notes: 'Réglé en Ariary au comptoir',
    cashierName: 'Caissier',
  },
];

export const INITIAL_EXPENSES: Expense[] = [
  {
    id: 'exp-1',
    timestamp: Date.now() - 1000 * 60 * 160,
    dateString: getTodayString(),
    timeString: '08:40:00',
    category: 'papier_encre',
    description: 'Achat 1 Ramette papier A4 80g (500 feuilles)',
    amount: 18000, // 18 000 Ar
    paymentMethod: 'especes',
    beneficiary: 'Papeterie',
  },
  {
    id: 'exp-2',
    timestamp: Date.now() - 1000 * 60 * 60,
    dateString: getTodayString(),
    timeString: '11:15:00',
    category: 'electricite_internet',
    description: 'Recharge Connexion Internet / Forfait Kiosque',
    amount: 5000, // 5 000 Ar
    paymentMethod: 'especes',
    beneficiary: 'Telma / Orange',
  },
];

const KEYS = {
  TASKS: 'multicaisse_tasks_nambinina_v3',
  TRANSACTIONS: 'multicaisse_transactions_nambinina_v3',
  EXPENSES: 'multicaisse_expenses_nambinina_v3',
  CLOSINGS: 'multicaisse_closings_nambinina_v3',
  SETTINGS: 'multicaisse_settings_nambinina_v3',
  OPENING_CASH: 'multicaisse_opening_cash_nambinina_v3',
};

export function loadTasks(): TaskType[] {
  try {
    const raw = localStorage.getItem(KEYS.TASKS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading tasks', e);
  }
  saveTasks(DEFAULT_TASKS);
  return DEFAULT_TASKS;
}

export function saveTasks(tasks: TaskType[]): void {
  try {
    localStorage.setItem(KEYS.TASKS, JSON.stringify(tasks));
  } catch (e) {
    console.error('Error saving tasks', e);
  }
}

export function loadTransactions(): Transaction[] {
  try {
    const raw = localStorage.getItem(KEYS.TRANSACTIONS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading transactions', e);
  }
  saveTransactions(INITIAL_TRANSACTIONS);
  return INITIAL_TRANSACTIONS;
}

export function saveTransactions(transactions: Transaction[]): void {
  try {
    localStorage.setItem(KEYS.TRANSACTIONS, JSON.stringify(transactions));
  } catch (e) {
    console.error('Error saving transactions', e);
  }
}

export function loadExpenses(): Expense[] {
  try {
    const raw = localStorage.getItem(KEYS.EXPENSES);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading expenses', e);
  }
  saveExpenses(INITIAL_EXPENSES);
  return INITIAL_EXPENSES;
}

export function saveExpenses(expenses: Expense[]): void {
  try {
    localStorage.setItem(KEYS.EXPENSES, JSON.stringify(expenses));
  } catch (e) {
    console.error('Error saving expenses', e);
  }
}

export function loadClosings(): DailyClosing[] {
  try {
    const raw = localStorage.getItem(KEYS.CLOSINGS);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Error loading closings', e);
  }
  return [];
}

export function saveClosings(closings: DailyClosing[]): void {
  try {
    localStorage.setItem(KEYS.CLOSINGS, JSON.stringify(closings));
  } catch (e) {
    console.error('Error saving closings', e);
  }
}

export function loadSettings(): BusinessSettings {
  try {
    const raw = localStorage.getItem(KEYS.SETTINGS);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch (e) {
    console.error('Error loading settings', e);
  }
  saveSettings(DEFAULT_SETTINGS);
  return DEFAULT_SETTINGS;
}

export function saveSettings(settings: BusinessSettings): void {
  try {
    localStorage.setItem(KEYS.SETTINGS, JSON.stringify(settings));
  } catch (e) {
    console.error('Error saving settings', e);
  }
}

export function getTodayOpeningCash(defaultVal: number): number {
  try {
    const saved = localStorage.getItem(KEYS.OPENING_CASH);
    if (saved) {
      const parsed = JSON.parse(saved);
      if (parsed.date === getTodayString()) {
        return parsed.amount;
      }
    }
  } catch {
    // fallback
  }
  return defaultVal;
}

export function setTodayOpeningCash(amount: number): void {
  try {
    localStorage.setItem(
      KEYS.OPENING_CASH,
      JSON.stringify({ date: getTodayString(), amount })
    );
  } catch (e) {
    console.error('Error setting opening cash', e);
  }
}
